#!/bin/bash
#
# Created at 2007-04-05
# Author: Andreas Draeger
#
# usage: ./install.sh [architecture of the processor]
#
# if no architecure is given 32 bit is assumed.

if [ "$1" == "" ]; then
  architecture="32"
else
  architecture=$1
fi

cd ..
installdir=$(pwd)

if test -e linux${1}; then
  echo "Directory linux"${1}" is already existing."
else
  mkdir linux${1}
fi
if test -e tmp; then
  echo "Directory tmp is already existing."
else
  mkdir tmp
fi
cd tmp

#########################################
# X E R C E S - I N S T A L L A T I O N #
#########################################
#
echo "Installing XERXES on your system"
#
wget http://mirrorspace.org/apache/xerces/c/3/sources/xerces-c-3.0.0.tar.gz
mkdir ../linux${1}/xerces
gunzip xerces-c-3.0.0.tar.gz
tar -xvf xerces-c-3.0.0.tar
rm xerces-c-3.0.0.tar
cd xerces-c-3.0.0
./configure --enable-msgloader-inmemory --prefix=$installdir/linux${1}/xerces --exec-prefix=$installdir/linux${1}/xerces
make
make install
make clean
# cd ../../../
cd ..
# now we are in the tmp directory.

###########################################
# L I B S B M L - I N S T A L L A T I O N #
###########################################

echo $(pwd)

echo "Installing libSBML on your system"
wget http://dfn.dl.sourceforge.net/sourceforge/sbml/libsbml-3.2.0-src.zip
# cp ../install/libsbml-3.2.0-src.zip .
mkdir $installdir/linux${1}/libSBML
unzip libsbml-3.2.0-src.zip
#echo $(pwd)
cd libsbml-3.2.0
chmod +x configure
./configure --with-java --with-xerces="${installdir}/linux${1}/xerces" \
  --prefix="${installdir}/linux${1}/libSBML" \
  --exec-prefix="${installdir}/linux${1}/libSBML"
#--with-swig="${installdir}/linux${1}/swig" #--with-perl --with-lisp
#--with-python --with-matlab
make
make install
/sbin/ldconfig
if [ "$LD_LIBRARY_PATH" == "" ]; then
  export LD_LIBRARY_PATH=$installdir/linux${1}/libSBML
else
  export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$installdir/linux${1}/libSBML
fi
cd ..
# now we are in tmp.
rm *.zip


#######################################################
# C L E A R  W O R K S P A C E                        #
#######################################################
cd $installdir/install
rm -rf ../tmp
rm -rf $installdir/linux${1}/libSBML/include
rm -rf $installdir/linux${1}/xerces/include
