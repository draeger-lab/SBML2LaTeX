/**
 * Nov, 2007 Copyright (c) ZBiT, University of T&uuml;bingen, Germany Compiler:
 * JDK 1.6.0
 */
package org.sbml.displaysbml;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import org.jdom.JDOMException;
import org.sbml.libsbml.ASTNode;
import org.sbml.libsbml.AlgebraicRule;
import org.sbml.libsbml.CVTerm;
import org.sbml.libsbml.Compartment;
import org.sbml.libsbml.CompartmentType;
import org.sbml.libsbml.Constraint;
import org.sbml.libsbml.Date;
import org.sbml.libsbml.Event;
import org.sbml.libsbml.FunctionDefinition;
import org.sbml.libsbml.InitialAssignment;
import org.sbml.libsbml.KineticLaw;
import org.sbml.libsbml.ListOf;
import org.sbml.libsbml.ListOfCompartments;
import org.sbml.libsbml.ListOfEvents;
import org.sbml.libsbml.ListOfFunctionDefinitions;
import org.sbml.libsbml.ListOfParameters;
import org.sbml.libsbml.ListOfReactions;
import org.sbml.libsbml.ListOfRules;
import org.sbml.libsbml.ListOfSpecies;
import org.sbml.libsbml.ListOfUnitDefinitions;
import org.sbml.libsbml.Model;
import org.sbml.libsbml.ModelCreator;
import org.sbml.libsbml.ModelHistory;
import org.sbml.libsbml.ModifierSpeciesReference;
import org.sbml.libsbml.Parameter;
import org.sbml.libsbml.Reaction;
import org.sbml.libsbml.Rule;
import org.sbml.libsbml.SBMLDocument;
import org.sbml.libsbml.SBMLError;
import org.sbml.libsbml.SBase;
import org.sbml.libsbml.Species;
import org.sbml.libsbml.SpeciesReference;
import org.sbml.libsbml.SpeciesType;
import org.sbml.libsbml.Unit;
import org.sbml.libsbml.UnitDefinition;
import org.sbml.libsbml.XMLAttributes;
import org.sbml.libsbml.libsbmlConstants;

import cz.kebrt.html2latex.FatalErrorException;
import cz.kebrt.html2latex.HTML2LaTeX;

/**
 * This class displays the whole information content of an SBML model in a LaTeX
 * file which can then be further processed, i.e., to a PDF file.
 * 
 * @since 2.0
 * @version 1.0
 * @author <a href="mailto:andreas.draeger@uni-tuebingen.de">Andreas
 *         Dr&auml;ger</a>
 * @author <a href="mailto:dwouamba@yahoo.fr">Dieudonne Motsou Wouamba</a>
 * @date December 4, 2007
 */
public class LaTeXExport implements libsbmlConstants, DisplaySBML {

	/**
	 * The file separator of the operating system.
	 */
	private static final String fileSeparator = System
			.getProperty("file.separator");

	/**
	 * The location of the SBML2LaTeX logo file.
	 */
	private static String logo;

	/**
	 * This is the link to the MIRIAM resources.
	 */
	private static final MIRIAMparser miriam = new MIRIAMparser();

	/* MiriamLink miriam = new MiriamLink(); */
	static {
		/*
		 * // Sets the address to access the Web Services miriam.setAddress(
		 * "http://www.ebi.ac.uk/compneur-srv/miriamws-main/MiriamWebServices");
		 */
		try {
			miriam.setMIRIAMfile(System.getProperty("user.dir") + fileSeparator
					+ "resources" + fileSeparator + "MIRIAM.xml");
		} catch (JDOMException exc) {
			exc.printStackTrace();
		} catch (IOException exc) {
			exc.printStackTrace();
		}
		logo = (new File(System.getProperty("user.dir") + fileSeparator
				+ "resources" + fileSeparator + "SBML2LaTeX.eps"))
				.getAbsolutePath();
		logo = logo.substring(0, logo.lastIndexOf('.'));
	}

	/**
	 * New line separator of this operating system
	 */
	private static final String newLine = System.getProperty("line.separator");

	/**
	 * This is a LaTeX line break. The line break symbol double backslash
	 * followed by a new line symbol of the operating system.
	 */
	private static final String lineBreak = "\\\\" + newLine;

	/**
	 * Surrounded by new line symbols. Begin equation. This type of equation
	 * requires the LaTeX package breqn. It will produce equations with
	 * automatic line breaks (LaTeX will compute the optimal place for line
	 * breaks). Unfortunately, this does not work for very long denominators.
	 */
	private static final String eqBegin = newLine + "\\begin{dmath}" + newLine; // equation

	/**
	 * End equation; cf. eqBegin. Surrounded by new line symbols.
	 */
	private static final String eqEnd = newLine + "\\end{dmath}" + newLine; // equation

	/**
	 * Needed for the beginning of a table. Requires LaTeX package booktabs.
	 * Surounded by new line symbols.
	 */
	private static final String toprule = newLine + "\\toprule" + newLine;

	/**
	 * Produces a fancy line in tables. Requires LaTeX package booktabs. Starts
	 * and ends with a new line.
	 */
	private static final String midrule = newLine + "\\midrule" + newLine;

	/**
	 * Requires LaTeX package booktabs. Produces a fancy line at the bottom of a
	 * table. This variable also includes the <code>end{longtable}</code>
	 * command and a new line.
	 */
	private static final String bottomrule = "\\bottomrule\\end{longtable}"
			+ newLine;

	/**
	 * A fancy symbol for saying yes. Requires the Zapf fonts in LaTeX.
	 */
	private static final String yes = "\\ding{51}";

	/**
	 * A fancy symbol for saying no. Requires the Zapf fonts in LaTeX.
	 */
	private static final String no = "\\ding{53}";

	/**
	 * Surrounded by new line symbols. The begin of a description environment in
	 * LaTeX.
	 */
	private static final String descriptionBegin = "\\begin{description}"
			+ newLine;

	/**
	 * Surrounded by new line symbols. The end of a description environment.
	 */
	private static final String descriptionEnd = "\\end{description}" + newLine;

	/**
	 * Set of SBO Term used in the current SBML document to be translated. This
	 * set stores the SBO ids.
	 */
	private Set<Integer> sboTerms = new HashSet<Integer>();

	/**
	 * This is the font size to be used in this document. Allowed values are:
	 * <ul>
	 * <li>8</li>
	 * <li>9</li>
	 * <li>10</li>
	 * <li>11</li>
	 * <li>12</li>
	 * <li>14</li>
	 * <li>16</li>
	 * <li>17</li>
	 * </ul>
	 * Other values are set to the default of 11.
	 */
	private short fontSize;

	/**
	 * Allowed are
	 * <ul>
	 * <li>letter</li>
	 * <li>legal</li>
	 * <li>executive</li>
	 * <li>a* where * stands for values from 0 thru 9</li>
	 * <li>b*</li>
	 * <li>c*</li>
	 * <li>d*</li>
	 * </ul>
	 * The default is a4.
	 */
	private String paperSize;

	/**
	 * This variable is needed to decide whether a method should write a
	 * document head and tail for the LaTeX output.
	 */
	private boolean headTail;

	/**
	 * If true species (reactants, modifiers and products) in reaction equations
	 * will be displayed with their name if they have one. By default the ids of
	 * the species are used in these equations.
	 */
	private boolean printNameIfAvailable;

	/**
	 * If true this will produce LaTeX files for for entirely landscape
	 * documents
	 */
	private boolean landscape;

	/**
	 * If true ids are set in typewriter font (default).
	 */
	private boolean typeWriter;

	/**
	 * If true SBML built-in units will be made explicitly if not overridden in
	 * the model.
	 */
	private boolean showImplicitUnitDeclarations;

	/**
	 * If true a title page will be created by LaTeX for the resulting document.
	 * Otherwise there will only be a title on top of the first page.
	 */
	private boolean titlepage;

	/**
	 * If true a section of all errors found in the SBML file are printed at the
	 * end of the document
	 */
	private boolean checkConsistency = false;

	/**
	 * If true MIRIAM annotations are included into the model report. This
	 * process takes a bit time due to the necessary connection to EBI's
	 * web-service.
	 */
	private boolean includeMIRIAM = false;

	/**
	 * Constructs a new instance of LaTeX export. For each document to be
	 * translated a new instance has to be created. Here default values are used
	 * (A4 paper, 11pt, portrait, fancy headings, no titlepage).
	 */
	public LaTeXExport() {
		this(false, true, (short) 11, "a4", true, false, false);
	}

	/**
	 * Constructs a new instance of LaTeX export. For each document to be
	 * translated a new instance has to be created. This constructor allows you
	 * to set many properties of the resulting LaTeX file.
	 * 
	 * @param landscape
	 *            If <code>true</code> the whole document will be set to
	 *            landscape format, otherwise portrait.
	 * @param typeWriter
	 *            If <code>true</code> ids are set in typewriter font (default).
	 *            Otherwise the regular font is used.
	 * @param fontSize
	 *            The size of the font to be used here. The default is 11.
	 *            Allowed values are 8, 9, 10, 11, 12, 14, 16 and 17.
	 * @param paperSize
	 *            Allowed are
	 *            <ul>
	 *            <li>letter</li>
	 *            <li>legal</li>
	 *            <li>executive</li>
	 *            <li>a* where * stands for values from 0 thru 9</li>
	 *            <li>b*</li>
	 *            <li>c*</li>
	 *            <li>d*</li>
	 *            </ul>
	 * @param addMissingUnitDeclarations
	 *            If true SBML built-in units will be made explicitly if not
	 *            overridden in the model.
	 * @param titlepage
	 *            if true a title page will be created for the model report.
	 *            Default is false (just a caption).
	 */
	public LaTeXExport(boolean landscape, boolean typeWriter, short fontSize,
			String paperSize, boolean addMissingUnitDeclarations,
			boolean titlepage, boolean printNameIfAvailable) {
		this.headTail = true;
		setLandscape(landscape);
		setTypeWriter(typeWriter);
		setFontSize(fontSize);
		setPaperSize(paperSize);
		setShowImplicitUnitDeclarations(addMissingUnitDeclarations);
		setTitlepage(titlepage);
		setPrintNameIfAvailable(printNameIfAvailable);
	}

	/**
	 * Method that transforms any libSBML abstract syntax tree (mathematical
	 * formula) of into LaTeX code.
	 * 
	 * @param model
	 *            The model, which contains this abstract syntax tree
	 * @param astnode
	 *            The node of the abstract syntax tree to be transformed
	 *            recursively, i.e., the subtree rooted at this node will be
	 *            translated into LaTeX.
	 * @return String An expression in LaTeX format describing the subtree
	 *         rooted at the given astnode.
	 * @throws IOException
	 */
	public StringBuffer toLaTeX(Model model, ASTNode astnode)
			throws IOException {
		StringBuffer value = new StringBuffer();

		if (astnode == null) {
			value.append("\\mathrm{undefined}");
			return value;
		}

		if (astnode.isUMinus()) {
			if (astnode.getLeftChild().getLeftChild() != null) {
				value.append("- \\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)");

				return value;
			} else {
				value.append("-");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				return value;

			}
		} else if (astnode.isSqrt()) {
			value.append("\\sqrt{");
			value.append(toLaTeX(model, astnode.getLeftChild()));
			value.append("}");
			return value;
		} else if (astnode.isInfinity()) {
			return new StringBuffer("\\infty");
		} else if (astnode.isNegInfinity()) {
			return new StringBuffer("-\\infty");
		} else if (astnode.getType() == 293) { // log to different base as 2
			// and 10.

			if (astnode.getRightChild().getLeftChild() != null) {
				value.append("\\log_{");
				value.append(toLaTeX(model, astnode.getRightChild()));
				value.append("} {\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");

				return value;
			} else {
				value.append("\\log_{");
				value.append(toLaTeX(model, astnode.getRightChild()));
				value.append("} {");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		}
		/*
		 * Numbers
		 */
		value = new StringBuffer();
		switch (astnode.getType()) {
		case AST_REAL:
			double d = astnode.getReal();
			return (((int) d) - d == 0) ? new StringBuffer(Integer
					.toString((int) d)) : new StringBuffer(Double.toString(d));
		case AST_INTEGER:
			return new StringBuffer(Integer.toString(astnode.getInteger()));
			/*
			 * Basic Functions
			 */
		case AST_FUNCTION_LOG: {
			if (astnode.getRightChild().getLeftChild() != null) {
				value.append("\\log {\\left(");
				value.append(toLaTeX(model, astnode.getRightChild()));
				value.append("\\right)}");
				return value;
			} else {
				value.append("\\log_{");
				value.append(toLaTeX(model, astnode.getRightChild()));
				value.append("}");
				return value;
			}
		}
			/*
			 * Operators
			 */
		case AST_POWER:
			if (toLaTeX(model, astnode.getRightChild()).equals("1")) {

				if (astnode.getRightChild().getLeftChild() != null) {
					value.append("\\left(");
					value.append(toLaTeX(model, astnode.getLeftChild()));
					value.append("\\right)");
					return value;
				} else {
					new StringBuffer(toLaTeX(model, astnode.getLeftChild()));
				}

			} else {

				if (astnode.getRightChild().getLeftChild() != null) {
					value.append("\\left(");
					value.append(toLaTeX(model, astnode.getLeftChild()));
					value.append("\\right)^{");
					value.append(toLaTeX(model, astnode.getRightChild()));
					value.append("}");
					return value;
				} else {
					value.append(toLaTeX(model, astnode.getLeftChild()));
					value.append("^{");
					value.append(toLaTeX(model, astnode.getRightChild()));
					value.append("}");
					return value;
				}
			}
		case AST_PLUS:
			if (astnode.getNumChildren() > 0) {
				value.append(toLaTeX(model, astnode.getLeftChild()));
				ASTNode ast;
				for (int i = 1; i < astnode.getNumChildren(); i++) {
					ast = astnode.getChild(i);
					switch (ast.getType()) {
					case AST_MINUS:
						value.append("+ \\left(");
						value.append(toLaTeX(model, ast));
						value.append("\\right)");
						break;
					default:
						value.append(" + ");
						value.append(toLaTeX(model, ast));
						break;
					}
				}
				return value;
			}
		case AST_MINUS:
			if (astnode.getNumChildren() > 0) {
				value = toLaTeX(model, astnode.getLeftChild());
				ASTNode ast;
				for (int i = 1; i < astnode.getNumChildren(); i++) {
					ast = astnode.getChild(i);
					switch (ast.getType()) {
					case AST_PLUS:
						value.append(" -  \\left(");
						value.append(toLaTeX(model, ast));
						value.append("\\right)");
						break;
					default:
						value.append(" - ");
						value.append(toLaTeX(model, ast));
						break;
					}
				}
				return value;
			}
		case AST_TIMES:
			if (astnode.getNumChildren() > 0) {
				value = toLaTeX(model, astnode.getLeftChild());
				if (astnode.getLeftChild().getNumChildren() > 1
						&& (astnode.getLeftChild().getType() == AST_MINUS || astnode
								.getLeftChild().getType() == AST_PLUS)) {
					StringBuffer sb = new StringBuffer("\\left(");
					sb.append(value);
					sb.append("\\right)");
					value = new StringBuffer(sb);
				}
				ASTNode ast;
				for (int i = 1; i < astnode.getNumChildren(); i++) {
					ast = astnode.getChild(i);
					switch (ast.getType()) {
					case AST_MINUS: {
						value.append("\\cdot\\left(");
						value.append(toLaTeX(model, ast));
						value.append("\\right)");
					}
						break;
					case AST_PLUS: {
						value.append("\\cdot\\left(");
						value.append(toLaTeX(model, ast));
						value.append("\\right)");
					}
						break;
					default: {
						value.append("\\cdot ");
						value.append(toLaTeX(model, ast));
					}
						break;
					}
				}
				return value;
			}

		case AST_DIVIDE:
			value = new StringBuffer("\\frac{");
			value.append(toLaTeX(model, astnode.getLeftChild()));
			value.append("}{");
			value.append(toLaTeX(model, astnode.getRightChild()));
			value.append("}");
			return value;
		case AST_RATIONAL:
			if (Double.toString(astnode.getDenominator()).toString()
					.equals("1"))
				return new StringBuffer(Double.toString(astnode.getNumerator()));
			else {
				value = new StringBuffer("\\frac{");
				value.append(Double.toString(astnode.getNumerator()));
				value.append("}{");
				value.append(Double.toString(astnode.getDenominator()));
				value.append("}");
				return value;
			}

		case AST_NAME_TIME:
			value = new StringBuffer("\\mathrm{");
			value.append(astnode.getName());
			value.append('}');
			return value;

		case AST_FUNCTION_DELAY:
			value = new StringBuffer("\\mathrm{");
			value.append(astnode.getName());
			value.append('}');
			return value;

			/*
			 * Names of identifiers: parameters, functions, species etc.
			 */
		case AST_NAME:

			if (model.getSpecies(astnode.getName()) != null) {
				// Species.
				Species species = model.getSpecies(astnode.getName());
				Compartment c = model.getCompartment(species.getCompartment());
				boolean concentration = !species.getHasOnlySubstanceUnits()
						&& (0 < c.getSpatialDimensions());
				value = new StringBuffer();
				if (concentration)
					value.append('[');
				value.append(getNameOrID(species, true));
				if (concentration) {
					value.append("]"); // \\cdot
					// value.append(getSize(c));
				}
				return value;

			} else if (model.getCompartment(astnode.getName()) != null) {
				// Compartment
				Compartment c = model.getCompartment(astnode.getName());
				return getSize(c);
			}

			// TODO: weitere spezialfälle von Namen!!!
			return new StringBuffer(mathtt(maskLaTeXspecialSymbols(astnode
					.getName())));
			/*
			 * Constants: pi, e, true, false
			 */
		case AST_CONSTANT_PI:
			return new StringBuffer("\\pi");
		case AST_CONSTANT_E:
			return new StringBuffer("\\mathrm{e}");
		case AST_CONSTANT_TRUE:
			return new StringBuffer("\\mathbf{true}");
		case AST_CONSTANT_FALSE:
			return new StringBuffer("\\mathbf{false}");
		case AST_REAL_E:
			return new StringBuffer(Double.toString(astnode.getReal()));
			/*
			 * More complicated functions
			 */
		case AST_FUNCTION_ABS:
			value = new StringBuffer("\\left\\lvert");
			value.append(toLaTeX(model, astnode.getRightChild()));
			value.append("\\right\\rvert");
			return value;

		case AST_FUNCTION_ARCCOS:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\arrcos{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\arccos{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_ARCCOSH:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\mathrm{arccosh}{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\mathrm{arccosh}{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_ARCCOT:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\arcot{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\arcot{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_ARCCOTH:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\mathrm{arccoth}{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\mathrm{arccoth}{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_ARCCSC:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\arccsc{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\arccsc{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_ARCCSCH:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\mathrm{arccsh}\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\mathrm{arccsh}");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_ARCSEC:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\arcsec{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\arcsec{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_ARCSECH:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\mathrm{arcsech}{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\mathrm{arcsech}{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_ARCSIN:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\arcsin{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\arcsin{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_ARCSINH:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\mathrm{arcsinh}{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\mathrm{arcsinh}{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_ARCTAN:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\arctan{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\arctan{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_ARCTANH:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\arctanh{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\arctanh{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_CEILING:
			value = new StringBuffer("\\left\\lceil ");
			value.append(toLaTeX(model, astnode.getLeftChild()));
			value.append("\\right\\rceil ");
			return value;
		case AST_FUNCTION_COS:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\cos{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\cos{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_COSH:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\cosh{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\cosh{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_COT:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\cot{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\cot{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_COTH:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\coth{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\coth{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_CSC:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\csc{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\csc{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_CSCH:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\mathrm{csch}{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\mathrm{csch}{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_EXP:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\exp{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\exp{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_FACTORIAL:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)!");
				return value;
			} else {
				value = new StringBuffer(toLaTeX(model, astnode.getLeftChild()));
				value.append("!");
				return value;
			}
		case AST_FUNCTION_FLOOR:
			value = new StringBuffer("\\left\\lfloor ");
			value.append(toLaTeX(model, astnode.getLeftChild()));
			value.append("\\right\\rfloor ");
			return value;
		case AST_FUNCTION_LN:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\ln{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\ln{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_POWER:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)^{");
				value.append(toLaTeX(model, astnode.getRightChild()));
				value.append("}");
				return value;
			} else {
				value = new StringBuffer(toLaTeX(model, astnode.getLeftChild()));
				value.append("^{");
				value.append(toLaTeX(model, astnode.getRightChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_ROOT:
			value = new StringBuffer("\\sqrt");
			ASTNode left = astnode.getLeftChild();
			if ((astnode.getNumChildren() > 1)
					&& ((left.isInteger() && (left.getInteger() != 2)) || (left
							.isReal() && (left.getReal() != 2d)))) {
				value.append('[');
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append(']');
			}
			value.append('{');
			value.append(toLaTeX(model, astnode.getChild(astnode
					.getNumChildren() - 1)));
			value.append("}");
			return value;
		case AST_FUNCTION_SEC:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\sec{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\sec{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_SECH:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\mathrm{sech}{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\mathrm{sech}{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_SIN:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\sin{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\sin{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_SINH:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\sinh{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\sinh{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_TAN:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\tan{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\tan{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION_TANH:
			if (astnode.getLeftChild().getLeftChild() != null) {
				value = new StringBuffer("\\tanh{\\left(");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("\\right)}");
				return value;
			} else {
				value = new StringBuffer("\\tanh{");
				value.append(toLaTeX(model, astnode.getLeftChild()));
				value.append("}");
				return value;
			}
		case AST_FUNCTION:
			value = new StringBuffer(mathtt(maskLaTeXspecialSymbols(astnode
					.getName())));
			value.append('(');
			for (int i = 0; i < astnode.getNumChildren(); i++) {
				if (i > 0)
					value.append(", ");
				value.append(toLaTeX(model, astnode.getChild(i)));
			}
			value.append(")");
			return value;
		case AST_LAMBDA:
			value = new StringBuffer(mathtt(maskLaTeXspecialSymbols(astnode
					.getName())));
			value.append('(');
			for (int i = 0; i < astnode.getNumChildren() - 1; i++) {
				if (i > 0)
					value.append(", ");
				value.append(toLaTeX(model, astnode.getChild(i)));
			}
			value.append(") = ");
			value.append(toLaTeX(model, astnode.getRightChild()));
			return value;
		case AST_LOGICAL_AND:
			return mathematicalOperation(astnode, model, "\\wedge ");
		case AST_LOGICAL_XOR:
			return mathematicalOperation(astnode, model, "\\oplus ");
		case AST_LOGICAL_OR:
			return mathematicalOperation(astnode, model, "\\lor ");
		case AST_LOGICAL_NOT:
			value = new StringBuffer("\\neg ");
			if (0 < astnode.getLeftChild().getNumChildren())
				value.append("\\left(");
			value.append(toLaTeX(model, astnode.getLeftChild()));
			if (0 < astnode.getLeftChild().getNumChildren())
				value.append("\\right)");
			return value;
		case AST_FUNCTION_PIECEWISE:
			value = new StringBuffer("\\begin{dcases}");
			value.append(newLine);
			for (long i = 0; i < astnode.getNumChildren() - 1; i++) {
				value.append(toLaTeX(model, astnode.getChild(i)));
				if ((i % 2) == 0)
					value.append(" & \\text{if\\ } ");
				else
					value.append(lineBreak);
			}
			value.append(toLaTeX(model, astnode.getRightChild()));
			if ((astnode.getNumChildren() % 2) == 1) {
				value.append(" & \\text{otherwise}");
				value.append(newLine);
			}
			value.append("\\end{dcases}");
			return value;
		case AST_RELATIONAL_EQ:
			value = new StringBuffer(toLaTeX(model, astnode.getLeftChild()));
			value.append(" \\eq ");
			value.append(toLaTeX(model, astnode.getRightChild()));
			return value;
		case AST_RELATIONAL_GEQ:
			value = new StringBuffer(toLaTeX(model, astnode.getLeftChild()));
			value.append(" \\geq ");
			value.append(toLaTeX(model, astnode.getRightChild()));
			return value;
		case AST_RELATIONAL_GT:
			value = new StringBuffer(toLaTeX(model, astnode.getLeftChild()));
			value.append(" > ");
			value.append(toLaTeX(model, astnode.getRightChild()));
			return value;
		case AST_RELATIONAL_NEQ:
			value = new StringBuffer(toLaTeX(model, astnode.getLeftChild()));
			value.append(" \\neq ");
			value.append(toLaTeX(model, astnode.getRightChild()));
			return value;
		case AST_RELATIONAL_LEQ:
			value = new StringBuffer(toLaTeX(model, astnode.getLeftChild()));
			value.append(" \\leq ");
			value.append(toLaTeX(model, astnode.getRightChild()));
			return value;
		case AST_RELATIONAL_LT:
			value = new StringBuffer(toLaTeX(model, astnode.getLeftChild()));
			value.append(" < ");
			value.append(toLaTeX(model, astnode.getRightChild()));
			return value;
		case AST_UNKNOWN:
			return new StringBuffer("\\text{ unknown }");
		default:
			break;
		}
		return new StringBuffer("\\text{ unknown }");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.jcell.client.io.DisplaySBML#format(org.sbml.libsbml.SBMLDocument,
	 * java.io.BufferedWriter)
	 */
	public void format(SBMLDocument doc, BufferedWriter buffer)
			throws IOException {
		/*
		 * writing latex head
		 */
		headTail = false;
		documentHead(doc, buffer);
		// buffer.append("\\tableofcontents");
		buffer.newLine();
		buffer.newLine();

		/*
		 * Overview
		 */
		buffer.append("\\section{General Overview}");
		buffer.newLine();
		buffer.append("This is a document in SBML Level ");
		buffer.append(Long.toString(doc.getLevel()));
		buffer.append(" Version ");
		buffer.append(Long.toString(doc.getVersion()));
		buffer.append(" format. ");
		format(doc, buffer, false);
		if (doc.isSetNotes()) {
			buffer.newLine();
			buffer.append("\\subsection*{Document Notes}");
			buffer.newLine();
			buffer.append(formatHTML(doc.getNotesString()));
			buffer.newLine();
		}

		/*
		 * The model: append model description
		 */
		if (doc.getModel() != null)
			format(doc.getModel(), buffer);

		if (checkConsistency) {
			doc.checkConsistency();
			if (doc.getNumErrors() > 0) {
				long i;
				SBMLError error;
				Vector<Long> infos = new Vector<Long>();
				Vector<Long> warnings = new Vector<Long>();
				Vector<Long> fatal = new Vector<Long>();
				Vector<Long> system = new Vector<Long>();
				Vector<Long> xml = new Vector<Long>();
				Vector<Long> internal = new Vector<Long>();
				Vector<Long> errors = new Vector<Long>();
				for (i = 0; i < doc.getNumErrors(); i++) {
					error = doc.getError(i);
					if (error.isInfo())
						infos.add(Long.valueOf(i));
					else if (error.isWarning())
						warnings.add(Long.valueOf(i));
					else if (error.isFatal())
						fatal.add(Long.valueOf(i));
					else if (error.isSystem())
						system.add(Long.valueOf(i));
					else if (error.isXML())
						xml.add(Long.valueOf(i));
					else if (error.isInternal())
						internal.add(Long.valueOf(i));
					else
						// error.isError())
						errors.add(Long.valueOf(i));
				}
				buffer.append("\\section{Model Consistency Report}");
				buffer.newLine();
				buffer.append("The given SBML document contains ");
				buffer.append(getWordForNumber(doc.getNumErrors()));
				buffer.append(" problem");
				if (doc.getNumErrors() > 1)
					buffer.append('s');
				buffer.append(", which are listed in ");
				buffer.append("the remainder of this model report.");
				if (xml.size() > 0)
					problemMessage(xml, doc, xml.size() > 1 ? "XML errors"
							: "XML error", buffer, "Error");
				if (fatal.size() > 0)
					problemMessage(fatal, doc,
							fatal.size() > 1 ? "Fatal errors" : "Fatal error",
							buffer, "Error");
				if (system.size() > 0)
					problemMessage(system, doc,
							system.size() > 1 ? "System messages"
									: "System message", buffer, "Error");
				if (internal.size() > 0)
					problemMessage(internal, doc,
							internal.size() > 1 ? "Internal problems"
									: "Internal problem", buffer, "Error");
				if (errors.size() > 0)
					problemMessage(errors, doc,
							errors.size() > 1 ? "Error messages"
									: "Error message", buffer, "Error");
				if (infos.size() > 0)
					problemMessage(infos, doc,
							infos.size() > 1 ? "Information messages"
									: "Information message", buffer,
							"Information");
				if (warnings.size() > 0)
					problemMessage(warnings, doc,
							warnings.size() > 1 ? "Warnings" : "Warning",
							buffer, "Warning");
			}
		}

		documentFoot(doc, buffer);
		headTail = true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jcell.client.io.DisplaySBML#format(org.sbml.libsbml.Model,
	 * java.io.BufferedWriter)
	 */
	public void format(Model model, BufferedWriter buffer) throws IOException {
		if (headTail) {
			documentHead(model.getSBMLDocument(), buffer);
			// buffer.append("\\tableofcontents");
			buffer.newLine();
			buffer.newLine();
			buffer.append("\\section{General Overview}");
			buffer.newLine();
		}
		if (model.isSetSBOTerm()) {
			sboTerms.add(Integer.valueOf(model.getSBOTerm()));
			buffer.append("The SBO concept of this model is a");
			String sboModelName = SBOParser.getSBOTermName(model.getSBOTerm());
			buffer.append(isVocal(sboModelName.charAt(0)) ? "n " : " ");
			buffer.append(sboModelName);
			buffer.append(". Its SBO term is ");
			buffer.append(getSBOnumber(model.getSBOTerm()));
			buffer
					.append(". See Section~\\ref{sec:glossary} for the definition.");
			buffer.newLine();
		}

		if (model.isSetModelHistory()) {
			// buffer.newLine();
			// buffer.append("\\subsection*{Model History}");
			// buffer.newLine();
			ModelHistory history = model.getModelHistory();
			if ((history.getNumCreators() > 0) || (history.isSetCreatedDate())) {
				buffer.append("This model was ");
				if (history.getNumCreators() > 0) {
					buffer.append("created by ");
					if (history.getNumCreators() > 1) {
						buffer.append("the following ");
						buffer
								.append(getWordForNumber(history
										.getNumCreators()));
						buffer.append(" authors: ");
					}
					for (long i = 0; i < history.getNumCreators(); i++) {
						if (history.getNumCreators() > 1
								&& (i == history.getNumCreators() - 1))
							buffer.append(" and ");
						else if (i > 0)
							buffer.append(", ");
						format(history.getCreator(i), buffer);
					}
					buffer.newLine();
				}
				if (history.isSetCreatedDate()) {
					buffer.append("at ");
					format(history.getCreatedDate(), buffer);
					if (history.isSetModifiedDate())
						buffer.append(" and ");
				}
			}
			if (history.isSetModifiedDate()) {
				buffer.append("last time modified at ");
				format(history.getModifiedDate(), buffer);
			}
			if ((history.getNumCreators() > 0)
					&& !(history.isSetCreatedDate() || history
							.isSetModifiedDate()))
				buffer.append('.');
			buffer.newLine();
		}

		buffer.append("Table~\\ref{tab:components} ");
		double random = Math.random();
		if (random <= 0.33)
			buffer.append("provides");
		else if (random <= 0.66)
			buffer.append("shows");
		else
			buffer.append("gives");
		buffer
				.append(" an overview of the quantities of all components of this model.");
		buffer.newLine();
		buffer.append("\\begin{table}[h!]");
		buffer.newLine();
		buffer.append("\\centering");
		buffer.newLine();
		buffer.append("\\caption{Number of components in this model, which");
		buffer.append(" are described in the following sections.}");
		buffer.append("\\label{tab:components}");
		buffer.newLine();
		// buffer.append("\\begin{tabular}{C{2cm}ccC{2cm}ccccC{2cm}}");
		buffer.append("\\begin{tabular}{l|r||l|r}");
		buffer.append(toprule);
		buffer
				.append("\\multicolumn{1}{c}{Element}&\\multicolumn{1}{|c||}{Quantity}&");
		buffer
				.append("\\multicolumn{1}{c|}{Element}&\\multicolumn{1}{c}{Quantity}");
		buffer.append(lineBreak);
		buffer.append(midrule);
		buffer.append("compartment types&");
		buffer.append(Long.toString(model.getNumCompartmentTypes()));
		buffer.append("&compartments&");
		buffer.append(Long.toString(model.getNumCompartments()));
		buffer.append(lineBreak);
		buffer.append("species types&");
		buffer.append(Long.toString(model.getNumSpeciesTypes()));
		buffer.append("&species&");
		buffer.append(Long.toString(model.getNumSpecies()));
		buffer.append(lineBreak);
		buffer.append("events&");
		buffer.append(Long.toString(model.getNumEvents()));
		buffer.append("&constraints&");
		buffer.append(Long.toString(model.getNumConstraints()));
		buffer.append(lineBreak);
		buffer.append("reactions&");
		buffer.append(Long.toString(model.getNumReactions()));
		buffer.append("&function definitions&");
		buffer.append(Long.toString(model.getNumFunctionDefinitions()));
		buffer.append(lineBreak);
		buffer.append("global parameters&");
		buffer.append(Long.toString(model.getNumParameters()));
		buffer.append("&unit definitions&");
		buffer.append(Long.toString(model.getNumUnitDefinitions()));
		buffer.append(lineBreak);
		buffer.append("rules&");
		buffer.append(Long.toString(model.getNumRules()));
		buffer.append("&initial assignments&");
		buffer.append(Long.toString(model.getNumInitialAssignments()));
		buffer.append(lineBreak);
		buffer.append("\\bottomrule\\end{tabular}");
		buffer.newLine();
		buffer.append("\\end{table}");
		buffer.newLine();

		if (model.isSetNotes()) {
			buffer.newLine();
			buffer.append("\\subsection*{Model Notes}");
			buffer.newLine();
			buffer.append(formatHTML(model.getNotesString()));
			buffer.newLine();
		}

		if ((model.getNumCVTerms() > 0) && (includeMIRIAM)) {
			buffer.newLine();
			buffer.append("\\subsection*{Model Annotation}");
			buffer.newLine();
			buffer.append("The following resources provide further ");
			buffer.append("information about this model:");
			buffer.newLine();
			for (long i = 0; i < model.getNumCVTerms(); i++)
				format(model.getCVTerm(i), buffer);
		}

		format(model.getListOfUnitDefinitions(), buffer);
		format(model.getListOfCompartmentTypes(), buffer, true);
		format(model.getListOfCompartments(), buffer, true);
		format(model.getListOfSpeciesTypes(), buffer, true);
		format(model.getListOfSpecies(), buffer, true);
		format(model.getListOfParameters(), buffer, true);
		format(model.getListOfInitialAssignments(), buffer, true);
		format(model.getListOfFunctionDefinitions(), buffer, true);
		format(model.getListOfRules(), buffer, true);
		format(model.getListOfEvents(), buffer);
		format(model.getListOfConstraints(), buffer, true);
		if (model.getNumReactions() == 0)
			model.getListOfReactions().setSBMLDocument(model.getSBMLDocument());
		format(model.getListOfReactions(), buffer, true);
		if (headTail)
			documentFoot(model.getSBMLDocument(), buffer);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jcell2.client.io.DisplaySBML#format(org.sbml.libsbml.ListOf,
	 * java.lang.String, java.io.BufferedWriter, boolean)
	 */
	public void format(ListOf list, BufferedWriter buffer, boolean section)
			throws IOException {
		long i;
		boolean compartments = list instanceof ListOfCompartments;
		boolean species = list instanceof ListOfSpecies;
		boolean reactions = list instanceof ListOfReactions;
		boolean parameters = list instanceof ListOfParameters;
		if (headTail)
			documentHead(list.getSBMLDocument(), buffer);
		if (list.size() > 0) {
			String name = list.get(0).getElementName().toLowerCase();
			boolean setLandscape = false;
			if (paperSize.equals("executive") || paperSize.equals("legal")
					|| paperSize.equals("letter"))
				setLandscape = true;
			else {
				short size = Short.parseShort(Character.toString(paperSize
						.charAt(1)));
				char variant = paperSize.charAt(0);
				if ((size >= 4)
						&& ((variant == 'a') || (variant == 'b')
								|| (variant == 'c') || (variant == 'd')))
					setLandscape = true;
			}
			setLandscape = setLandscape && !landscape;
			if (species || reactions) {
				if (setLandscape) {
					buffer.newLine();
					buffer.append("\\begin{landscape}");
				}
				buffer.newLine();
			} else if (list instanceof ListOfRules)
				name = "rule";
			else if (list instanceof ListOfFunctionDefinitions)
				name = "function definition";
			else if (name.endsWith("type"))
				name = name.substring(0, name.length() - 4) + " type";

			if (section) {
				buffer.append("\\section{");
				buffer.append(Character.toUpperCase(name.charAt(0)));
				buffer.append(name.substring(1));
				buffer.append((list.size() > 1) && (!name.endsWith("s")) ? "s}"
						: "}");
				buffer.newLine();
				if (compartments || species || reactions || parameters)
					buffer.append("This model contains ");
				else
					buffer.append("This is an overview of ");
				buffer.append(getWordForNumber(list.size()));
				if (parameters)
					buffer.append(" global");
				buffer.append(name.charAt(0) == ' ' ? name : " " + name);
				buffer.append((list.size() > 1) && (!name.endsWith("s")) ? "s."
						: ".");
				buffer.newLine();
				if (species) {
					if (list.getModel().getNumSpeciesWithBoundaryCondition() > 0) {
						buffer.append("The boundary condition of ");
						buffer.append(getWordForNumber(list.getModel()
								.getNumSpeciesWithBoundaryCondition()));
						buffer.append(" of these species is set to ");
						buffer.append(texttt("true"));
						buffer.append(" so that th");
						buffer
								.append(list.getModel()
										.getNumSpeciesWithBoundaryCondition() > 1 ? "ese"
										: "is");
						buffer
								.append(" species' amount cannot be changed by any reaction. ");
					}
					buffer.append("Section~\\ref{sec:DerivedRateEquations} ");
					buffer.append("provides further details and the derived ");
					buffer.append("rates of change of each species.");
					buffer.newLine();
				}
			}

			if (compartments)
				buffer.append(longtableHead("@{}lllC{2cm}llcl@{}",
						"Properties of all compartments.",
						"id&name&SBO&spatial dimensions&"
								+ "size&unit&constant&outside"));
			else if (species)
				buffer
						.append(longtableHead(
								paperSize.equals("letter")
										|| paperSize.equals("executive") ? "@{}p{3.5cm}p{6cm}p{4.5cm}p{2.5cm}C{1.5cm}C{1.5cm}@{}"
										: "@{}p{3.5cm}p{6.5cm}p{5cm}p{3cm}C{1.5cm}C{1.5cm}@{}",
								"Properties of each species.",
								"id&name&compartment&derived unit&"
										+ "constant&boundary condition"));
			else if (reactions) {
				buffer.append(" All reactions are listed in the following");
				buffer.append(" table and are subsequently described in");
				buffer.append(" detail. If a reaction is affected by a");
				buffer.append(" modifier, the name of this species is");
				buffer.append(" written above the reaction arrow.");
				buffer.newLine();
				buffer.append(longtableHead("rp{3cm}p{7cm}p{8cm}p{1.5cm}",
						"Overview of all reactions",
						"\\numero&id&name&reaction equation&SBO"));
			} else if (parameters) {
				long preDecimal = 1, postDecimal = 1;
				for (i = 0; i < list.size(); i++) {
					String[] value = Double.toString(
							((Parameter) list.get(i)).getValue()).split("\\.");
					if (value[0].length() > preDecimal)
						preDecimal = value[0].length();
					if (value[1].length() > postDecimal) {
						postDecimal = value[1].length();
						if (value[1].contains("E"))
							postDecimal += 2;
					}
				}
				String head;
				if (paperSize.equals("executive"))
					head = "p{2cm}p{3cm}cR{";
				else
					head = "p{2.5cm}p{3cm}cR{";
				head += Long.toString(preDecimal) + "}{"
						+ Long.toString(Math.min(postDecimal, 3));
				head += (paperSize.equals("executive")) ? "}p{2.8cm}c"
						: "}p{3cm}c";
				buffer.append(longtableHead(head,
						"Properties of each parameter.",
						"\\multicolumn{1}{l}{id}&name&SBO&\\multicolumn{1}{c}{value}&"
								+ "unit&\\multicolumn{1}{c}{constant}"));
			}

			/*
			 * Iterate over all elements in the list and format them
			 * appropriately
			 */
			for (i = 0; i < list.size(); i++) {
				SBase s = list.get(i);
				if (section
						&& !(compartments || species || reactions || parameters)) {
					buffer.newLine();
					buffer.append("\\subsection{");
					buffer.append(Character.toUpperCase(name.charAt(0)));
					buffer.append(name.substring(1));
					buffer.append(' ');
					buffer.append(texttt(maskLaTeXspecialSymbols(s.getId())));
					buffer.append('}');
					if (s instanceof Rule) {
						buffer.newLine();
						buffer.append("\\label{rule" + s.getId() + "}");
					}
				}
				if (parameters) {
					buffer.append(texttt(maskLaTeXspecialSymbols(s.getId())));
					buffer.append('&');
					if (s.isSetName())
						buffer.append(maskLaTeXspecialSymbols(s.getName()));
					buffer.append('&');
					if (s.isSetSBOTerm()) {
						buffer.append(getSBOnumber(s.getSBOTerm()));
						sboTerms.add(Integer.valueOf(s.getSBOTerm()));
					}
					buffer.append('&');
					Parameter p = (Parameter) s;
					String value = Double.toString(p.getValue());
					buffer.append(value.contains("E") ? "\\multicolumn{1}{r}{"
							+ format(p.getValue()) + "}" : value);
					buffer.append('&');
					UnitDefinition ud = p.getDerivedUnitDefinition();
					if ((ud == null) || (ud.getNumUnits() == 0)) {
						if (p.isSetUnits()) {
							if ((ud = p.getModel().getUnitDefinition(
									p.getUnits())) != null) {
								buffer.append('$');
								buffer.append(format(ud));
								buffer.append('$');
							} else if (p.getUnits().equals("dimensionless"))
								buffer.append(p.getUnits());
							else
								buffer.append(texttt(maskLaTeXspecialSymbols(p
										.getUnits())));
						} else
							buffer.append(' ');
					} else {
						buffer.append('$');
						buffer.append(format(ud));
						buffer.append('$');
					}
					buffer.append('&');
					buffer.append(p.getConstant() ? yes : no);
					buffer.append(lineBreak);
				} else if (compartments) {
					Compartment c = (Compartment) s;
					if (c.isSetId())
						buffer
								.append(texttt(maskLaTeXspecialSymbols(c
										.getId())));
					buffer.append('&');
					buffer.append(maskLaTeXspecialSymbols(c.getName()));
					buffer.append('&');
					if (c.isSetSBOTerm()) {
						buffer.append(getSBOnumber(c.getSBOTerm()));
						sboTerms.add(Integer.valueOf(c.getSBOTerm()));
					}
					buffer.append('&');
					buffer.append(Long.toString(c.getSpatialDimensions()));
					buffer.append('&');
					buffer.append(format(c.getSize()));
					buffer.append("&$");
					UnitDefinition ud;
					if (c.isSetUnits())
						ud = c.getModel().getUnitDefinition(c.getUnits());
					else
						ud = c.getDerivedUnitDefinition();
					if (ud == null)
						buffer.append(' ');
					else if (ud.isVariantOfVolume() && (ud.getNumUnits() == 1)
							&& (c.getSize() == 1.0)
							&& (ud.getUnit(0).isLitre()))
						buffer.append("\\mathrm{litre}");
					else
						buffer.append(format(ud));
					buffer.append("$&");
					buffer.append(c.getConstant() ? yes : no);
					buffer.append('&');
					buffer
							.append(texttt(maskLaTeXspecialSymbols(c
									.getOutside())));
					buffer.append(lineBreak);
				} else if (species) {
					String mask = maskLaTeXspecialSymbols(s.getId());
					buffer.append(texttt(mask));
					buffer.append('&');
					buffer.append(maskLaTeXspecialSymbols(s.getName()));
					buffer.append("&");
					buffer.append(texttt(maskLaTeXspecialSymbols(((Species) s)
							.getCompartment())));
					buffer.append("&$");
					buffer.append(format(((Species) s)
							.getDerivedUnitDefinition()));
					buffer.append("$&");
					buffer.append(((Species) s).getConstant() ? yes : no);
					buffer.append('&');
					buffer.append(((Species) s).getBoundaryCondition() ? yes
							: no);
					buffer.append(lineBreak);
				} else if (reactions) {
					buffer.append(Long.toString(i + 1));
					buffer.append('&');
					Reaction r = (Reaction) list.get(i);
					// buffer.append("\\hyperref[v");
					// buffer.append(Long.toString(i + 1));
					// buffer.append("]{");
					buffer.append(texttt(maskLaTeXspecialSymbols(r.getId())));
					// buffer.append("}&");
					buffer.append('&');
					buffer.append(r.isSetName() ? maskLaTeXspecialSymbols(r
							.getName()) : " ");
					buffer.append("&\\ce{");
					buffer.append(reactionEquation(r));
					buffer.append("}&");
					if (r.isSetSBOTerm()) {
						buffer.append(getSBOnumber(r.getSBOTerm()));
						sboTerms.add(Integer.valueOf(r.getSBOTerm()));
					}
					buffer.append(lineBreak);
				} else if (s instanceof Constraint) {
					Constraint c = (Constraint) s;
					buffer.append(descriptionBegin);
					format(c, buffer, true);
					buffer.append(descriptionItem("Message", formatHTML(
							c.getMessageString()).toString()));
					buffer.append("\\item[Equation] ");
					buffer.append(eqBegin);
					buffer.append(toLaTeX(c.getModel(), c.getMath()));
					buffer.append(eqEnd);
					buffer.append(descriptionEnd);
				} else if (s instanceof FunctionDefinition)
					format((FunctionDefinition) s, buffer);
				else if (s instanceof InitialAssignment)
					format((InitialAssignment) s, buffer);
				else if (s instanceof Rule)
					format((Rule) s, buffer);
				else if ((s instanceof SpeciesType)
						|| (s instanceof CompartmentType)) {
					boolean isSpecType = s instanceof SpeciesType;
					StringBuffer sb = new StringBuffer();
					long j, counter = 0;
					if (isSpecType)
						for (j = 0; j < s.getModel().getNumSpecies(); j++) {
							Species spec = s.getModel().getSpecies(j);
							if (spec.isSetSpeciesType()
									&& spec.getSpeciesType().equals(s.getId())) {
								sb.append(texttt(maskLaTeXspecialSymbols(spec
										.getId())));
								sb.append('&');
								if (spec.isSetName())
									sb.append(maskLaTeXspecialSymbols(spec
											.getName()));
								sb.append(lineBreak);
								counter++;
							}
						}
					else
						for (j = 0; j < s.getModel().getNumCompartments(); j++) {
							Compartment c = s.getModel().getCompartment(j);
							if (c.isSetCompartmentType()
									&& c.getCompartmentType().equals(s.getId())) {
								sb.append(texttt(maskLaTeXspecialSymbols(c
										.getId())));
								sb.append('&');
								if (c.isSetName())
									sb.append(maskLaTeXspecialSymbols(c
											.getName()));
								sb.append(lineBreak);
								counter++;
							}
						}
					format(s, buffer, false);
					if (counter == 0) {
						buffer.append("This model does not contain any ");
						buffer.append(isSpecType ? "species" : "compartments");
						buffer.append(" of this type.");
					} else {
						buffer.append(longtableHead("@{}ll@{}",
								(isSpecType ? "Species" : "Compartments")
										+ " of this type", "id&name"));
						buffer.append(sb);
						buffer.append(bottomrule);
					}
				} else
					format(s, buffer, false);
			}
			if (parameters || compartments || species || reactions) {
				buffer.append(bottomrule);
				if ((species || reactions) && setLandscape) {
					buffer.append("\\end{landscape}");
					buffer.newLine();
				}
			}
			buffer.newLine();
		}
		if (reactions)
			format((ListOfReactions) list, buffer);
		if (compartments)
			format((ListOfCompartments) list, buffer);
		if (headTail)
			documentFoot(list, buffer);
	}

	/**
	 * 
	 */
	public void format(ListOfEvents eventList, BufferedWriter buffer)
			throws IOException {
		if (headTail)
			documentHead(eventList.getSBMLDocument(), buffer);
		if (eventList.size() > 0) {
			LinkedList<StringBuffer>[] events = new LinkedList[(int) eventList
					.size()];
			long i;
			buffer.newLine();
			buffer.append("\\section{Event");
			buffer.append((eventList.size() > 1) ? "s}" : "}");
			buffer.newLine();
			buffer.append("This is an overview of ");
			buffer.append(getWordForNumber(eventList.size()));
			buffer.append(" event");
			buffer.append(eventList.size() == 1 ? "." : "s.");
			buffer.append(" Each event is initiated whenever its");
			buffer.append(" trigger condition switches from ");
			buffer.append(texttt("false"));
			buffer.append(" to ");
			buffer.append(texttt("true"));
			buffer.append(". A delay function postpones the effects");
			buffer.append(" of an event to a later time point.");
			buffer.append(" At the time of execution, an event");
			buffer.append(" can assign values to species, ");
			buffer.append(" parameters or compartments if these");
			buffer.append(" are not set to constant.");
			buffer.newLine();

			Event ev;
			for (i = 0; i < eventList.size(); i++) {
				ev = (Event) eventList.get(i);
				events[(int) i] = new LinkedList<StringBuffer>();
				events[(int) i].add(toLaTeX(ev.getModel(), ev.getTrigger()
						.getMath()));
				for (int j = 0; j < ev.getNumEventAssignments(); j++)
					events[(int) i].add(toLaTeX(ev.getModel(), ev
							.getEventAssignment(j).getMath()));
			}
			String var;
			for (i = 0; i < events.length; i++) {
				ev = (Event) eventList.get(i);
				buffer.append("\\subsection{Event "
						+ texttt(maskLaTeXspecialSymbols(ev.getId())) + "}");
				buffer.newLine();
				buffer.append("\\label{event" + ev.getId() + "}");
				buffer.newLine();
				format(ev, buffer, false);
				buffer.append("\\textbf{\\sffamily Trigger condition}");
				buffer.append(eqBegin);
				buffer.append(events[(int) i].get(0).toString());
				buffer.append(eqEnd);
				if (ev.isSetDelay()) {
					buffer.append("\\textbf{\\sffamily Delay}");
					buffer.append(eqBegin);
					buffer.append(toLaTeX(ev.getModel(), ev.getDelay()
							.getMath()));
					UnitDefinition ud = ev.getDelay()
							.getDerivedUnitDefinition();
					buffer.append(eqEnd);
					if ((ud != null) && (ud.getNumUnits() > 0)) {
						buffer
								.append("\\textbf{\\sffamily Time unit of the delay} $");
						buffer.append(format(ud));
						buffer.append('$');
					}
				}
				buffer.append("\\textbf{\\sffamily Assignment");
				if (ev.getNumEventAssignments() > 1) {
					buffer.append("s}");
					buffer.newLine();
					buffer.append("\\begin{align}");
				} else {
					buffer.append('}');
					buffer.append(eqBegin);
				}
				for (int j = 0; j < events[(int) i].size() - 1; j++) {
					var = ev.getEventAssignment(j).getVariable();
					Model model = ev.getModel();
					if (model.getSpecies(var) != null) {
						Species species = model.getSpecies(var);
						if (species.getHasOnlySubstanceUnits())
							buffer.append('[');
						buffer.append(mathtt(maskLaTeXspecialSymbols(model
								.getSpecies(var).getId())));
						if (species.getHasOnlySubstanceUnits())
							buffer.append(']');
					} else if (model.getCompartment(var) != null)
						buffer.append(getSize(model.getCompartment(var)));
					else
						buffer.append(mathtt(maskLaTeXspecialSymbols(var)));
					buffer.append((ev.getNumEventAssignments() > 1) ? " =& "
							: " = ");
					buffer.append(events[(int) i].get(j + 1));
					if (j < events[(int) i].size() - 2)
						buffer.append(lineBreak);
				}
				if (ev.getNumEventAssignments() == 1)
					buffer.append(eqEnd);
				else {
					buffer.append("\\end{align}");
					buffer.newLine();
				}
			}
		}
		buffer.newLine();
		if (headTail)
			documentFoot(eventList, buffer);
	}

	/**
	 * Creates a readable format of all unit definitions within the given list.
	 * 
	 * @param listOfUnits
	 * @param buffer
	 * @throws IOException
	 */
	public void format(ListOfUnitDefinitions listOfUnits, BufferedWriter buffer)
			throws IOException {
		if (headTail)
			documentHead(listOfUnits.getSBMLDocument(), buffer);
		int countDefaults = 0;
		UnitDefinition def;
		if (showImplicitUnitDeclarations) {
			Unit u;
			String notes = " is the default SBML built-in unit for <tt>";
			if (listOfUnits.get("substance") == null) {
				def = new UnitDefinition("substance");
				def.addUnit(new Unit("mole"));
				def.setNotes("Mole" + notes + def.getId() + "</tt>.");
				listOfUnits.append(def);
				countDefaults++;
			}
			if (listOfUnits.get("volume") == null) {
				def = new UnitDefinition("volume");
				def.addUnit(new Unit("litre"));
				def.setNotes("Litre" + notes + def.getId() + "</tt>.");
				listOfUnits.append(def);
				countDefaults++;
			}
			if (listOfUnits.get("area") == null) {
				def = new UnitDefinition("area");
				u = new Unit("metre");
				u.setExponent(2);
				def.addUnit(u);
				def.setNotes("Square metre" + notes + def.getId() + "</tt>.");
				listOfUnits.append(def);
				countDefaults++;
			}
			if (listOfUnits.get("length") == null) {
				def = new UnitDefinition("length");
				def.addUnit(new Unit("metre"));
				def.setNotes("Metre" + notes + def.getId() + "</tt>.");
				listOfUnits.append(def);
				countDefaults++;
			}
			if (listOfUnits.get("time") == null) {
				def = new UnitDefinition("time");
				def.addUnit(new Unit("second"));
				def.setNotes("Second" + notes + def.getId() + "</tt>.");
				listOfUnits.append(def);
				countDefaults++;
			}
		}
		if (0 < listOfUnits.size()) {
			buffer.append("\\section{Unit Definition");
			buffer.append(listOfUnits.size() > 1 ? "s}" : "}");
			buffer.newLine();
			buffer.append("This is an overview of ");
			buffer.append(getWordForNumber(listOfUnits.size()));
			buffer.append(" unit definition");
			if (listOfUnits.size() > 1)
				buffer.append('s');
			if (0 < countDefaults) {
				buffer
						.append(((countDefaults < listOfUnits.size()) ? " of which "
								+ getWordForNumber(countDefaults) + " are"
								: " which are all")
								+ " defined implicitly by SBML and not "
								+ "mentioned in the model");
			}
			buffer.append('.');
			buffer.newLine();
			for (long i = 0; i < listOfUnits.size(); i++) {
				def = (UnitDefinition) listOfUnits.get(i);
				buffer.append("\\subsection{Unit "
						+ texttt(maskLaTeXspecialSymbols(def.getId())) + "}");
				buffer.append(descriptionBegin);
				format(def, buffer, true);
				if (def.getNumUnits() > 0)
					buffer.append(descriptionItem("Definition", "$"
							+ format(def) + '$'));
				buffer.append(descriptionEnd);
			}
		}
		if (headTail)
			documentFoot(listOfUnits, buffer);
	}

	/**
	 * Returns a properly readable unit definition.
	 * 
	 * @param def
	 * @return
	 */
	public StringBuffer format(UnitDefinition def) {
		StringBuffer buffer = new StringBuffer();
		for (long j = 0; j < def.getNumUnits(); j++) {
			buffer.append(format((Unit) def.getListOfUnits().get(j)));
			if (j < def.getListOfUnits().size() - 1)
				buffer.append("\\cdot ");
		}
		return buffer;
	}

	/**
	 * Returns a unit.
	 * 
	 * @param u
	 * @return
	 */
	public StringBuffer format(Unit u) {
		StringBuffer buffer = new StringBuffer();
		boolean standardScale = (u.getScale() == 18) || (u.getScale() == 12)
				|| (u.getScale() == 9) || (u.getScale() == 6)
				|| (u.getScale() == 3) || (u.getScale() == 2)
				|| (u.getScale() == 1) || (u.getScale() == 0)
				|| (u.getScale() == -1) || (u.getScale() == -2)
				|| (u.getScale() == -3) || (u.getScale() == -6)
				|| (u.getScale() == -9) || (u.getScale() == -12)
				|| (u.getScale() == -15) || (u.getScale() == -18);
		boolean brackets = ((u.getOffset() != 0d) || (u.getMultiplier() != 1d) || !standardScale)
				&& (u.getExponent() != 1d);
		if (brackets)
			buffer.append("\\left(");
		if (u.getOffset() != 0d) {
			buffer.append(format(u.getOffset()).toString()
					.replaceAll("\\$", ""));
			if ((u.getMultiplier() != 0) || (!standardScale))
				buffer.append('+');
		}
		if (u.getMultiplier() != 1d) {
			if (u.getMultiplier() == -1d)
				buffer.append('-');
			else {
				buffer.append(format(u.getMultiplier()).toString().replaceAll(
						"\\$", ""));
				buffer.append(!standardScale ? "\\cdot " : "\\;");
			}
		}
		if (u.isKilogram()) {
			u.setScale(u.getScale() + 3);
			u.setKind(UNIT_KIND_GRAM);
		}
		if (!u.isDimensionless()) {
			switch (u.getScale()) {
			case 18:
				buffer.append("\\mathrm{E}");
				break;
			case 15:
				buffer.append("\\mathrm{P}");
				break;
			case 12:
				buffer.append("\\mathrm{T}");
				break;
			case 9:
				buffer.append("\\mathrm{G}");
				break;
			case 6:
				buffer.append("\\mathrm{M}");
				break;
			case 3:
				buffer.append("\\mathrm{k}");
				break;
			case 2:
				buffer.append("\\mathrm{h}");
				break;
			case 1:
				buffer.append("\\mathrm{da}");
				break;
			case 0:
				break;
			case -1:
				buffer.append("\\mathrm{d}");
				break;
			case -2:
				buffer.append("\\mathrm{c}");
				break;
			case -3:
				buffer.append("\\mathrm{m}");
				break;
			case -6:
				buffer.append("\\upmu");
				break;
			case -9:
				buffer.append("\\mathrm{n}");
				break;
			case -12:
				buffer.append("\\mathrm{p}");
				break;
			case -15:
				buffer.append("\\mathrm{f}");
				break;
			case -18:
				buffer.append("\\mathrm{a}");
				break;
			default:
				buffer.append("10^{");
				buffer.append(Integer.toString(u.getScale()));
				buffer.append("}\\cdot ");
				break;
			}
			switch (u.getKind()) {
			case UNIT_KIND_AMPERE:
				buffer.append("\\mathrm{A}");
				break;
			case UNIT_KIND_BECQUEREL:
				buffer.append("\\mathrm{Bq}");
				break;
			case UNIT_KIND_CANDELA:
				buffer.append("\\mathrm{cd}");
				break;
			case UNIT_KIND_CELSIUS:
				buffer.append("\\text{\\textcelsius}");
				break;
			case UNIT_KIND_COULOMB:
				buffer.append("\\mathrm{C}");
				break;
			case UNIT_KIND_DIMENSIONLESS:
				break;
			case UNIT_KIND_FARAD:
				buffer.append("\\mathrm{F}");
				break;
			case UNIT_KIND_GRAM:
				buffer.append("\\mathrm{g}");
				break;
			case UNIT_KIND_GRAY:
				buffer.append("\\mathrm{Gy}");
				break;
			case UNIT_KIND_HENRY:
				buffer.append("\\mathrm{H}");
				break;
			case UNIT_KIND_HERTZ:
				buffer.append("\\mathrm{Hz}");
				break;
			case UNIT_KIND_INVALID:
				buffer.append("\\mathrm{invalid}");
				break;
			case UNIT_KIND_ITEM:
				buffer.append("\\mathrm{item}");
				break;
			case UNIT_KIND_JOULE:
				buffer.append("\\mathrm{J}");
				break;
			case UNIT_KIND_KATAL:
				buffer.append("\\mathrm{kat}");
				break;
			case UNIT_KIND_KELVIN:
				buffer.append("\\mathrm{K}");
				break;
			// case UNIT_KIND_KILOGRAM:
			// buffer.append("\\mathrm{kg}");
			// break;
			case UNIT_KIND_LITER:
				buffer.append("\\mathrm{l}");
				break;
			case UNIT_KIND_LITRE:
				buffer.append("\\mathrm{l}");
				break;
			case UNIT_KIND_LUMEN:
				buffer.append("\\mathrm{lm}");
				break;
			case UNIT_KIND_LUX:
				buffer.append("\\mathrm{lx}");
				break;
			case UNIT_KIND_METER:
				buffer.append("\\mathrm{m}");
				break;
			case UNIT_KIND_METRE:
				buffer.append("\\mathrm{m}");
				break;
			case UNIT_KIND_MOLE:
				buffer.append("\\mathrm{mol}");
				break;
			case UNIT_KIND_NEWTON:
				buffer.append("\\mathrm{N}");
				break;
			case UNIT_KIND_OHM:
				buffer.append("\\upOmega");
				break;
			case UNIT_KIND_PASCAL:
				buffer.append("\\mathrm{Pa}");
				break;
			case UNIT_KIND_RADIAN:
				buffer.append("\\mathrm{rad}");
				break;
			case UNIT_KIND_SECOND:
				buffer.append("\\mathrm{s}");
				break;
			case UNIT_KIND_SIEMENS:
				buffer.append("\\mathrm{S}");
				break;
			case UNIT_KIND_SIEVERT:
				buffer.append("\\mathrm{Sv}");
				break;
			case UNIT_KIND_STERADIAN:
				buffer.append("\\mathrm{sr}");
				break;
			case UNIT_KIND_TESLA:
				buffer.append("\\mathrm{T}");
				break;
			case UNIT_KIND_VOLT:
				buffer.append("\\mathrm{V}");
				break;
			case UNIT_KIND_WATT:
				buffer.append("\\mathrm{W}");
				break;
			case UNIT_KIND_WEBER:
				buffer.append("\\mathrm{Wb}");
				break;
			}
		} else {
			if (u.getScale() != 0) {
				buffer.append("10^{");
				buffer.append(Integer.toString(u.getScale()));
				buffer.append("}\\;");
			}
			buffer.append("\\mathrm{dimensionless}");
		}
		if (brackets)
			buffer.append("\\right)");
		if (u.getExponent() != 1) {
			buffer.append("^{");
			buffer.append(Integer.toString(u.getExponent()));
			buffer.append('}');
		}
		return buffer;
	}

	/**
	 * Returns the number as a word. Zero is converted to "no". Only positive
	 * numbers from 1 to twelve can be converted. All other numbers are just
	 * converted to a String containing the number.
	 * 
	 * @param number
	 * @return
	 */
	public String getWordForNumber(long number) {
		if ((number < Integer.MIN_VALUE) || (Integer.MAX_VALUE < number))
			return Long.toString(number);
		switch ((int) number) {
		case 0:
			return "no";
		case 1:
			return "one";
		case 2:
			return "two";
		case 3:
			return "three";
		case 4:
			return "four";
		case 5:
			return "five";
		case 6:
			return "six";
		case 7:
			return "seven";
		case 8:
			return "eight";
		case 9:
			return "nine";
		case 10:
			return "ten";
		case 11:
			return "eleven";
		case 12:
			return "twelve";
		default:
			return Long.toString(number);
		}
	}

	/**
	 * 
	 * @param number
	 * @return
	 */
	public String getNumbering(long number) {
		if ((Integer.MIN_VALUE < number) && (number < Integer.MAX_VALUE))
			switch ((int) number) {
			case 1:
				return "first";
			case 2:
				return "second";
			case 3:
				return "third";
			case 5:
				return "fifth";
			case 13:
				return "thirteenth";
			default:
				if (number < 13) {
					String word = getWordForNumber(number);
					return word.endsWith("t") ? word + 'h' : word + "th";
				}
				break;
			}
		String numberWord = Long.toString(number);
		switch (numberWord.charAt(numberWord.length() - 1)) {
		case '1':
			return getWordForNumber(number) + "\\textsuperscript{st}";
		case '2':
			return getWordForNumber(number) + "\\textsuperscript{nd}";
		case '3':
			return getWordForNumber(number) + "\\textsuperscript{rd}";
		default:
			return getWordForNumber(number) + "\\textsuperscript{th}";
		}
	}

	/**
	 * Returns the name of a given month.
	 * 
	 * @param month
	 * @return
	 */
	public String getMonthName(short month) {
		switch (month) {
		case 1:
			return "January";
		case 2:
			return "February";
		case 3:
			return "March";
		case 4:
			return "April";
		case 5:
			return "May";
		case 6:
			return "June";
		case 7:
			return "July";
		case 8:
			return "August";
		case 9:
			return "September";
		case 10:
			return "October";
		case 11:
			return "November";
		case 12:
			return "December";
		default:
			return "invalid month " + month;
		}
	}

	public short getFontSize() {
		return fontSize;
	}

	/**
	 * @return the size of the paper to be used.
	 */
	public String getPaperSize() {
		return paperSize;
	}

	/**
	 * Returns true if the abstract syntax tree contains a node with the given
	 * name or id. To this end, the AST is traversed recursively.
	 * 
	 * @param id
	 * @param math
	 * @return
	 */
	public boolean contains(String id, ASTNode math) {
		if ((math.getType() == AST_NAME) && (math.getName().equals(id)))
			return true;
		for (int i = 0; i < math.getNumChildren(); i++)
			if (contains(id, math.getChild(i)))
				return true;
		return false;
	}

	/**
	 * @return true if names instead of ids are displayed in formulas and
	 *         reaction equations if available, i.e., the respective SBase has a
	 *         name attribute.
	 */
	public boolean isPrintNameIfAvailable() {
		return printNameIfAvailable;
	}

	/**
	 * Returns true if the given <code>UnitDefinition</code> is a variant of
	 * substance per time.
	 * 
	 * @param ud
	 * @return
	 */
	public boolean isVariantOfSubstancePerTime(UnitDefinition ud) {
		boolean perTime = false;
		UnitDefinition newUnit = new UnitDefinition(), testUnit, unitDefinition = (UnitDefinition) ud
				.cloneObject();
		UnitDefinition.simplify(unitDefinition);
		for (long i = 0; i < unitDefinition.getNumUnits(); i++) {
			Unit unit = unitDefinition.getUnit(i);
			testUnit = new UnitDefinition();
			testUnit.addUnit((Unit) unit.cloneObject());
			testUnit.getUnit(0).setExponent(1);
			if (testUnit.isVariantOfTime()) {
				if (unit.getExponent() == -1)
					perTime = true;
			} else
				newUnit.addUnit((Unit) unit.cloneObject());
		}
		return newUnit.isVariantOfSubstance() && perTime;
	}

	/**
	 * @return true if landscape format for the whole document is to be used.
	 */
	public boolean isLandscape() {
		return landscape;
	}

	/**
	 * @return true if implicitely declared units should be made explicit.
	 */
	public boolean isAddMissingUnitDeclarations() {
		return showImplicitUnitDeclarations;
	}

	/**
	 * @return true if ids are written in type writer font.
	 */
	public boolean isTypeWriter() {
		return typeWriter;
	}

	/**
	 * @return true if an extra title page is created false otherwise.
	 */
	public boolean isTitlepage() {
		return titlepage;
	}

	/**
	 * If this method returns true, this exporter performs a consistency check
	 * of the given SBML file and writes all errors and warnings found to at the
	 * end of the document.
	 * 
	 * @return
	 */
	public boolean isCheckConsistency() {
		return checkConsistency;
	}

	/**
	 * Lets you decide weather or not MIRIAM annotations should be included into
	 * the model report
	 * 
	 * @return
	 */
	public boolean isSetIncludeMiriam() {
		return includeMIRIAM;
	}

	/**
	 * Tells you if MIRIAM annotations will be included when generating a model
	 * report
	 * 
	 * @param includeMiriam
	 */
	public void setIncludeMiriam(boolean includeMiriam) {
		this.includeMIRIAM = includeMiriam;
	}

	/**
	 * This method allows you to set the MIRIAM XML file to be parsed for MIRIAM
	 * identifiers.
	 * 
	 * @param path
	 * @throws JDOMException
	 * @throws IOException
	 */
	public static void setMIRIAMfile(String path) throws JDOMException, IOException {
		miriam.setMIRIAMfile(path);
	}

	/**
	 * If set to true, an SBML consistency check of the document is performed
	 * and all errors found will be written at the end of the document.
	 * 
	 * @param checkConsistency
	 */
	public void setCheckConsistency(boolean checkConsistency) {
		this.checkConsistency = checkConsistency;
	}

	/**
	 * This is the font size to be used in this document.
	 * 
	 * @param Allowed
	 *            values are:
	 *            <ul>
	 *            <li>8</li>
	 *            <li>9</li>
	 *            <li>10</li>
	 *            <li>11</li>
	 *            <li>12</li>
	 *            <li>14</li>
	 *            <li>16</li>
	 *            <li>17</li>
	 *            </ul>
	 *            Other values are set to the default of 11.
	 * 
	 */
	public void setFontSize(short fontSize) {
		if ((fontSize < 8) || (fontSize == 13) || (17 < fontSize))
			this.fontSize = 11;
		this.fontSize = fontSize;
	}

	/**
	 * Allowed are
	 * <ul>
	 * <li>letter</li>
	 * <li>legal</li>
	 * <li>executive</li>
	 * <li>a* where * stands for values from 0 thru 9</li>
	 * <li>b*</li>
	 * <li>c*</li>
	 * <li>d*</li>
	 * </ul>
	 * The default is a4.
	 */
	public void setPaperSize(String paperSize) {
		paperSize = paperSize.toLowerCase();
		if (paperSize.equals("letter") || paperSize.equals("legal")
				|| paperSize.equals("executive"))
			this.paperSize = paperSize;
		else if (paperSize.length() == 2) {
			if (!Character.isDigit(paperSize.charAt(1))
					|| ((paperSize.charAt(0) != 'a')
							&& (paperSize.charAt(0) != 'b')
							&& (paperSize.charAt(0) != 'c') && (paperSize
							.charAt(0) != 'd')))
				this.paperSize = "a4";
			else {
				short size = Short.parseShort(Character.toString(paperSize
						.charAt(1)));
				if ((0 <= size) && (size < 10))
					this.paperSize = paperSize;
				else
					this.paperSize = "a4";
			}
		} else
			this.paperSize = "a4";
		this.paperSize = paperSize;
	}

	/**
	 * If true species (reactants, modifiers and products) in reaction equations
	 * will be displayed with their name if they have one. By default the ids of
	 * the species are used in these equations.
	 */
	public void setPrintNameIfAvailable(boolean printNameIfAvailable) {
		this.printNameIfAvailable = printNameIfAvailable;
	}

	/**
	 * If true an extra title page is created. Default false.
	 * 
	 * @param titlepage
	 */
	public void setTitlepage(boolean titlepage) {
		this.titlepage = titlepage;
	}

	/**
	 * If true is given the whole document will be created in landscape mode.
	 * Default is portrait.
	 * 
	 * @param landscape
	 */
	public void setLandscape(boolean landscape) {
		this.landscape = landscape;
	}

	/**
	 * If true SBML built-in units will be made explicitly if not overridden in
	 * the model.
	 * 
	 * @param showImplicitUnitDeclarations
	 */
	public void setShowImplicitUnitDeclarations(
			boolean showImplicitUnitDeclarations) {
		this.showImplicitUnitDeclarations = showImplicitUnitDeclarations;
	}

	/**
	 * If true ids are set in typewriter font (default).
	 * 
	 * @param typeWriter
	 */
	public void setTypeWriter(boolean typeWriter) {
		this.typeWriter = typeWriter;
	}

	private void format(ListOfCompartments list, BufferedWriter buffer)
			throws IOException {
		StringBuffer description;
		for (long i = 0; i < list.size(); i++) {
			Compartment c = (Compartment) list.get(i);
			buffer.newLine();
			buffer.append("\\subsection{Compartment ");
			buffer.append(texttt(maskLaTeXspecialSymbols(c.getId())));
			buffer.append('}');
			buffer.newLine();
			if (c.isSetName())
				buffer.append(firstLetterUpperCase(c.getName()));
			else
				buffer.append("This");
			buffer.append(" is a");
			String dimension = getWordForNumber(c.getSpatialDimensions());
			if (isVocal(dimension.charAt(0)))
				buffer.append('n');
			buffer.append(' ');
			buffer.append(dimension);
			buffer.append(" dimensional compartment ");
			if (c.isSetCompartmentType()) {
				buffer.append("of type ");
				description = texttt(maskLaTeXspecialSymbols(c
						.getCompartmentType()));
				CompartmentType type = c.getModel().getCompartmentType(
						c.getCompartmentType());
				if (type.isSetName()) {
					description.append(" (");
					description.append(maskLaTeXspecialSymbols(type.getName()));
					description.append(')');
				}
				buffer.append(description);
				buffer.append(' ');
			}
			buffer.append("with a ");
			if (!c.getConstant())
				buffer.append("not ");
			buffer.append("constant ");
			if (c.isSetSize()) {
				buffer.append("size of ");
				if (c.getSize() - ((long) c.getSize()) == 0)
					buffer.append(getWordForNumber((long) c.getSize()));
				else
					buffer.append(format(c.getSize()));
			} else
				buffer.append("size given in");
			String unitDef = format(c.getDerivedUnitDefinition()).toString();
			if (unitDef.equals("\\mathrm{l}"))
				unitDef = "litre";
			else
				unitDef = "$" + unitDef + "$";
			buffer.append("\\,");
			buffer.append(unitDef);
			if (c.isSetOutside()) {
				buffer.append(", which is surrounded by ");
				description = texttt(maskLaTeXspecialSymbols(c.getOutside()));
				Compartment outside = c.getModel().getCompartment(
						c.getOutside());
				if (outside.isSetName()) {
					description.append(" (");
					description.append(maskLaTeXspecialSymbols(outside
							.getName()));
					description.append(')');
				}
				buffer.append(description);
			}
			buffer.append('.');
			buffer.newLine();
			format((SBase) c, buffer, false);
		}
	}

	/**
	 * Returns a String who's first letter is now in upper case.
	 * 
	 * @param name
	 * @return
	 */
	private String firstLetterUpperCase(String name) {
		char c = name.charAt(0);
		if (Character.isLetter(c))
			c = Character.toUpperCase(c);
		if (name.length() > 1)
			name = Character.toString(c) + name.substring(1);
		else
			return Character.toString(c);
		return name;
	}

	/**
	 * Retunrs a String who's first letter is now in lower case.
	 * 
	 * @param name
	 * @return
	 */
	private String firstLetterLowerCase(String name) {
		char c = name.charAt(0);
		if (Character.isLetter(c))
			c = Character.toLowerCase(c);
		if (name.length() > 1)
			name = Character.toString(c) + name.substring(1);
		else
			return Character.toString(c);
		return name;
	}

	/**
	 * This method formats MIRIAM annotations or other annotations stored in CV
	 * terms (controlled vocabulary).
	 * 
	 * @param cv
	 * @param buffer
	 * @throws IOException
	 */
	private void format(CVTerm cv, BufferedWriter buffer) throws IOException {
		buffer.append("According to MIRIAM this ");
		switch (cv.getQualifierType()) {
		case MODEL_QUALIFIER:
			buffer.append("model ");
			switch (cv.getModelQualifierType()) {
			case BQM_IS:
				buffer.append("is");
				break;
			case BQM_IS_DESCRIBED_BY:
				buffer.append("is described by");
				break;
			default: // unknown
				buffer.append("has something to do with");
				break;
			}
			break;
		case BIOLOGICAL_QUALIFIER:
			buffer.append("biological entity ");
			switch (cv.getBiologicalQualifierType()) {
			case BQB_ENCODES:
				buffer.append("encodes");
				break;
			case BQB_HAS_PART:
				buffer.append("has a part");
				break;
			case BQB_HAS_VERSION:
				buffer.append("has the version");
				break;
			case BQB_IS:
				buffer.append("is");
				break;
			case BQB_IS_DESCRIBED_BY:
				buffer.append("is described by");
				break;
			case BQB_IS_ENCODED_BY:
				buffer.append("is encoded by");
				break;
			case BQB_IS_HOMOLOG_TO:
				buffer.append("is homolog to");
				break;
			case BQB_IS_PART_OF:
				buffer.append("is a part of");
				break;
			case BQB_IS_VERSION_OF:
				buffer.append("is a version of");
				break;
			/*
			 * case 9: buffer.append("occurs in"); break;
			 */
			default: // unknown
				buffer.append("has something to do with");
				break;
			}
			break;
		default: // UNKNOWN_QUALIFIER
			buffer.append("element has something to do with");
			break;
		}
		XMLAttributes resources = cv.getResources();
		String item = "";
		if (resources.getLength() > 1) {
			buffer.append(":\\begin{itemize}");
			buffer.newLine();
			item = "\\item ";
		} else
			buffer.append(' ');
		for (int i = 0; i < resources.getLength(); i++) {
			String identifier = resources.getValue(i);
			if (!identifier.startsWith("urn"))
				identifier = miriam.getMiriamURI(identifier);
			String urls[] = miriam.getLocations(identifier);
			identifier = maskLaTeXspecialSymbols(identifier, false);
			if (urls != null) {
				buffer.append(item);
				if (urls.length >= 1) {
					buffer.append(href(urls[0].replaceAll("\\%", "\\\\%"),
							texttt(identifier).toString()));
					buffer.append('.');
				} else
					buffer.append(" no URL available for resource identifier "
							+ texttt(identifier));
			}
			buffer.newLine();
		}
		if (resources.getLength() > 1)
			buffer.append("\\end{itemize}");
		buffer.newLine();
	}

	/**
	 * Formats the date properly.
	 * 
	 * @param createdDate
	 * @param buffer
	 * @throws IOException
	 */
	private void format(Date date, BufferedWriter buffer) throws IOException {
		buffer.append(getMonthName((short) date.getMonth()));
		buffer.append(' ');
		buffer.append(getNumbering(date.getDay()));
		buffer.append(' ');
		buffer.append(Long.toString(date.getYear()));
		buffer.append(" at ");
		if ((date.getMinute() == 0) || (date.getMinute() == 60)) {
			if (date.getHour() == 12)
				buffer.append("noon");
			else if (date.getHour() == 24)
				buffer.append("midnight");
			else
				buffer.append(Long.toString((date.getHour() > 12) ? date
						.getHour() - 12 : date.getHour()));
			buffer.append(" o' clock in the ");
			buffer.append(date.getHour() > 12 ? "afternoon" : "morning");
		} else {
			buffer.append(Long
					.toString((date.getHour() > 12) ? date.getHour() - 12
							: date.getHour()));
			buffer.append(':');
			buffer.append(Long.toString(date.getMinute()));
			buffer.append(date.getHour() > 12 ? "~p.\\,m." : "~a.\\,m.");
		}
	}

	/**
	 * 
	 * @param creator
	 * @param buffer
	 * @throws IOException
	 */
	private void format(ModelCreator creator, BufferedWriter buffer)
			throws IOException {
		if (creator.isSetGivenName())
			buffer.append(creator.getGivenName());
		if (creator.isSetFamilyName()) {
			if (creator.isSetGivenName())
				buffer.append(' ');
			buffer.append(creator.getFamilyName());
		}
		if ((creator.isSetGivenName() || creator.isSetFamilyName())
				&& (creator.isSetOrganisation() || creator.isSetEmail()))
			buffer.append("\\footnote{");
		if (creator.isSetOrganisation())
			buffer.append(creator.getOrganisation());
		if (creator.isSetEmail()) {
			if (creator.isSetOrganisation())
				buffer.append(", ");
			buffer.append(href("mailto:" + creator.getEmail(), "\\nolinkurl{"
					+ creator.getEmail() + '}'));
		}
		if ((creator.isSetGivenName() || creator.isSetFamilyName())
				&& (creator.isSetOrganisation() || creator.isSetEmail()))
			buffer.append('}');
	}

	/**
	 * Creates a list of reactions including the correct hyperreferences to the
	 * respective kinetic laws, in which the given species is involved in. This
	 * list is enclosed in parenthesis.
	 * 
	 * @param model
	 * @param speciesIndex
	 * @param reactantsReaction
	 * @param productsReaction
	 * @param buffer
	 * @throws IOException
	 */
	private void formatReactionsInvolved(Model model, long speciesIndex,
			List<Long>[] reactantsReaction, List<Long>[] productsReaction,
			BufferedWriter buffer) throws IOException {
		buffer.append("This species takes part in ");
		final long numReactionsInvolved = reactantsReaction[(int) speciesIndex]
				.size()
				+ productsReaction[(int) speciesIndex].size();
		buffer.append(getWordForNumber(numReactionsInvolved));
		buffer.append(" reaction");
		if (numReactionsInvolved > 1)
			buffer.append('s');
		buffer.append(" (");
		Reaction reaction;
		int numReactants = reactantsReaction[(int) speciesIndex].size();
		for (long i = 0, reactionIndex; i < numReactionsInvolved; i++) {
			if (i < numReactants)
				reactionIndex = reactantsReaction[(int) speciesIndex].get(
						(int) i).longValue();
			else
				reactionIndex = productsReaction[(int) speciesIndex].get(
						(int) i - numReactants).longValue();
			reaction = model.getReaction(reactionIndex - 1);
			if (0 < i)
				buffer.append(", ");
			buffer.append("\\hyperref[v");
			buffer.append(Long.toString(reactionIndex));
			buffer.append("]{");
			buffer.append(texttt(reaction.getId()));
			buffer.append('}');
		}
		buffer.append(')');
	}

	/**
	 * This converts HTML formatation tags into associated LaTeX format
	 * assignments.
	 * 
	 * @param note
	 * @return
	 * @throws IOException
	 */
	private static StringBuffer formatHTML(String note) throws IOException {
		try {
			StringWriter st = new StringWriter();
			BufferedWriter bw = new BufferedWriter(st);
			StringReader sr = new StringReader(note);
			BufferedReader br = new BufferedReader(sr);
			HTML2LaTeX.convert(br, bw);
			br.close();
			bw.close();
			StringBuffer sb = st.getBuffer();
			int index = sb.indexOf("\\begin{document}");
			if (index > -1)
				sb.delete(0, index + 16);
			index = sb.indexOf("\\end{document}");
			if (index > -1)
				sb.delete(index, sb.length());
			return sb;
		} catch (FatalErrorException exc) {
			exc.printStackTrace();
		}
		return new StringBuffer();
	}

	/**
	 * Colores a velocity if necessary.
	 * 
	 * @param k
	 * @param notSubstancePerTimeUnit
	 * @param notExistingKineticLaw
	 * @param equationBW
	 * @throws IOException
	 */
	private void formatVelocity(Long k, boolean notSubstancePerTimeUnit,
			boolean notExistingKineticLaw, BufferedWriter equationBW)
			throws IOException {
		// if (notSubstancePerTimeUnit || notExistingKineticLaw)
		equationBW.append("\\hyperref[v" + Long.toString(k) + "]{");
		if (notSubstancePerTimeUnit)
			equationBW.append("\\colorbox{lightgray}{$");
		else if (notExistingKineticLaw)
			equationBW.append("\\textcolor{red}{");
		equationBW.append("v_{");
		equationBW.append(Long.toString(k));
		equationBW.append('}');
		if (notExistingKineticLaw)
			equationBW.append("}}");
		else if (notSubstancePerTimeUnit)
			equationBW.append("$}}");
		else
			equationBW.append('}');
	}

	/**
	 * Formats name, SBO term and notes as items of a description environment.
	 * 
	 * @param sBase
	 * @param buffer
	 * @param onlyItems
	 *            If true items will be written otherwise this will be
	 *            surrounded by a description environment.
	 * @throws IOException
	 */
	private void format(SBase sBase, BufferedWriter buffer, boolean onlyItems)
			throws IOException {
		if (sBase.isSetName() || sBase.isSetNotes() || sBase.isSetSBOTerm()) {
			if (!onlyItems)
				buffer.append(descriptionBegin);
			if (sBase.isSetName())
				buffer.append(descriptionItem("Name",
						maskLaTeXspecialSymbols(sBase.getName())));
			if (sBase.isSetSBOTerm()) {
				buffer.append(descriptionItem("SBO", getSBOnumber(sBase
						.getSBOTerm())));
				sboTerms.add(Integer.valueOf(sBase.getSBOTerm()));
			}
			if (sBase.isSetNotes())
				buffer.append(descriptionItem("Notes", formatHTML(
						sBase.getNotesString()).toString()));
			if ((sBase.getNumCVTerms() > 0) && (includeMIRIAM)) {
				buffer.append("\\item[Annotation] ");
				for (long i = 0; i < sBase.getNumCVTerms(); i++) {
					format(sBase.getCVTerm(i), buffer);
					buffer.newLine();
				}
			}
			if (!onlyItems)
				buffer.append(descriptionEnd);
		}
	}

	/**
	 * 
	 * @param reactionList
	 * @param buffer
	 * @throws IOException
	 */
	private void format(ListOfReactions reactionList, BufferedWriter buffer)
			throws IOException {
		long reactionIndex, speciesIndex, sReferenceIndex;
		Species species;
		HashMap<String, Long> speciesIDandIndex = new HashMap<String, Long>();
		Model model = reactionList.getModel();
		if (model.getNumSpecies() > 0) {
			List<Long>[] reactantsReaction = new List[(int) model
					.getNumSpecies()];
			List<Long>[] productsReaction = new List[(int) model
					.getNumSpecies()];
			boolean notSubstancePerTimeUnit = false, notExistingKineticLaw = false;

			for (speciesIndex = 0; speciesIndex < model.getNumSpecies(); speciesIndex++) {
				speciesIDandIndex.put(model.getSpecies(speciesIndex).getId(),
						Long.valueOf(speciesIndex));
				reactantsReaction[(int) speciesIndex] = new Vector<Long>();
				productsReaction[(int) speciesIndex] = new Vector<Long>();
			}

			for (reactionIndex = 0; reactionIndex < reactionList.size(); reactionIndex++) {
				Reaction r = (Reaction) reactionList.get(reactionIndex);
				buffer.append(format(r, reactionIndex));
				if (!r.isSetKineticLaw())
					notExistingKineticLaw = true;
				else if (!isVariantOfSubstancePerTime(r.getKineticLaw()
						.getDerivedUnitDefinition()))
					notSubstancePerTimeUnit = true;
				for (sReferenceIndex = 0; sReferenceIndex < r.getNumReactants(); sReferenceIndex++) {
					speciesIndex = speciesIDandIndex.get(
							r.getReactant(sReferenceIndex).getSpecies())
							.longValue();
					reactantsReaction[(int) speciesIndex].add(Long
							.valueOf(reactionIndex + 1));
				}
				for (sReferenceIndex = 0; sReferenceIndex < r.getNumProducts(); sReferenceIndex++) {
					speciesIndex = speciesIDandIndex.get(
							r.getProduct(sReferenceIndex).getSpecies())
							.longValue();
					productsReaction[(int) speciesIndex].add(Long
							.valueOf(reactionIndex + 1));
				}
			}

			// writing Equations
			buffer.newLine();
			buffer.append("\\section{Derived Rate Equation");
			buffer.append((model.getNumSpecies() > 1) ? "s}" : "}");
			buffer.newLine();
			buffer.append("\\label{sec:DerivedRateEquations}");
			buffer.newLine();
			buffer
					.append("When interpreted as an ordinary differential equation framework, ");
			buffer.append("this model implies the following ");
			if (reactionList.size() == 1)
				buffer.append("equation");
			else
				buffer.append("set of equations");
			buffer.append(" for the rate");
			if (model.getNumSpecies() > 1)
				buffer.append("s of changes of each ");
			else
				buffer.append(" of change of the following ");
			buffer.append("species. ");
			buffer.newLine();

			if (notExistingKineticLaw) {
				buffer.newLine();
				buffer.append("The identifiers for reactions, ");
				buffer.append("which are not defined properly or ");
				buffer.append("which are lacking a kinetic equation, ");
				buffer.append("are highlighted in \\textcolor{red}{red}. ");
				buffer.newLine();
			}
			if (notSubstancePerTimeUnit) {
				buffer.newLine();
				buffer.append("Identifiers for kinetic laws highlighted in ");
				buffer.append("\\colorbox{lightgray}{gray} ");
				buffer.append(" cannot be verified  to evaluate to ");
				buffer.append("units of SBML ");
				buffer.append(texttt("substance"));
				buffer.append(" per ");
				buffer.append(texttt("time"));
				buffer.append(". As a result, some SBML interpreters may ");
				buffer.append("not be able to verify the consistency ");
				buffer.append("of the units on ");
				buffer.append("quantities in the model. Please check if ");
				buffer.newLine();
				buffer.append("\\begin{itemize}");
				buffer.newLine();
				buffer.append("\\item parameters without an unit definition");
				buffer.append(" are involved or");
				buffer.newLine();
				buffer.append("\\item volume correction is necessary");
				buffer.append(" because the ");
				buffer.append(texttt("has\\-Only\\-Substance\\-Units"));
				buffer.append(" flag may be set to ");
				buffer.append(texttt("false"));
				buffer.append(" and ");
				buffer.append(texttt("spacial\\-Di\\-men\\-si\\-ons"));
				buffer.append("$> 0$ for certain species.");
				buffer.newLine();
				buffer.append("\\end{itemize}");
				buffer.newLine();
			}

			for (speciesIndex = 0; speciesIndex < model.getNumSpecies(); speciesIndex++) {
				species = model.getSpecies(speciesIndex);
				buffer.append("\\subsection{Species ");
				buffer.append(texttt(maskLaTeXspecialSymbols(species.getId())));
				buffer.append('}');
				buffer.append(descriptionBegin);
				format(species, buffer, true);
				if (species.isSetInitialConcentration()) {
					buffer.append("\\item[Initial concentration] $");
					buffer.append(format(species.getInitialConcentration())
							.toString().replaceAll("\\$", ""));
					if ((model.getUnitDefinition("substance") != null)
							|| species.isSetSubstanceUnits()) {
						buffer.append("\\;");
						UnitDefinition ud = new UnitDefinition(species
								.isSetSubstanceUnits() ? model
								.getUnitDefinition(species.getSubstanceUnits())
								: model.getUnitDefinition("substance"));
						Compartment compartment = model.getCompartment(species
								.getCompartment());
						for (long i = 0; i < compartment
								.getDerivedUnitDefinition().getNumUnits(); i++) {
							Unit unit = new Unit(compartment
									.getDerivedUnitDefinition().getUnit(i));
							unit.setExponent(-unit.getExponent());
							ud.addUnit(unit);
						}
						buffer.append(format(ud));
					}
					buffer.append('$');
					buffer.newLine();
				} else if (species.isSetInitialAmount()) {
					buffer.append("\\item[Initial amount] $");
					buffer.append(format(species.getInitialAmount()).toString()
							.replaceAll("\\$", ""));
					if (species.isSetSubstanceUnits()) {
						buffer.append("\\;");
						buffer.append(format(model.getUnitDefinition(species
								.getSubstanceUnits())));
					} else if (model.getUnitDefinition("substance") != null) {
						buffer.append("\\;");
						buffer.append(format(model
								.getUnitDefinition("substance")));
					}
					buffer.append('$');
					// buffer.append(species.getSubstanceUnits());
					buffer.newLine();
				}
				if (species.isSetCharge())
					buffer.append(descriptionItem("Charge", Integer
							.toString(species.getCharge())));
				if (species.isSetSpeciesType()) {
					buffer.append("\\item[Species type]");
					SpeciesType type = model.getSpeciesType(species
							.getSpeciesType());
					buffer
							.append(texttt(maskLaTeXspecialSymbols(type.getId())));
					if (type.isSetName()) {
						buffer.append(" (");
						buffer.append(type.getName());
						buffer.append(")");
					}
					buffer.newLine();
				}
				// if (species.getBoundaryCondition()) {
				// buffer.append("\\item[Boundary condition] ");
				// buffer.append(yes);
				// buffer.newLine();
				// }
				// if (species.getConstant()) {
				// buffer.append("\\item[Constant] ");
				// buffer.append(yes);
				// buffer.newLine();
				// }

				int i, j;

				// ======= I N I T I A L A S S I G N M E N T S===========

				boolean hasInitialAssignment = false;
				for (i = 0; (i < model.getNumInitialAssignments()); i++) {
					hasInitialAssignment = model.getInitialAssignment(i)
							.getSymbol().equals(species.getId());
					if (hasInitialAssignment)
						break;
				}
				if (hasInitialAssignment) {
					buffer.append("\\item[Initial assignment] ");
					buffer.append(texttt(maskLaTeXspecialSymbols(model
							.getInitialAssignment(i - 1).getId())));
					buffer.newLine();
				}

				// =========== R U L E S and E V E N T S =================

				// Events, in which this species is involved in
				Vector<String> eventsInvolved = new Vector<String>();
				for (i = 0; i < model.getNumEvents(); i++) {
					Event event = model.getEvent(i);
					for (j = 0; j < event.getNumEventAssignments(); j++)
						if (event.getEventAssignment(j).getVariable().equals(
								species.getId()))
							eventsInvolved.add(event.getId());
				}
				if (eventsInvolved.size() > 0) {
					buffer.append("\\item[Involved in event");
					if (eventsInvolved.size() > 1)
						buffer.append('s');
					buffer.append("] ");
					for (i = 0; i < eventsInvolved.size(); i++) {
						String id = eventsInvolved.get(i);
						buffer.append("\\hyperref[event" + id + "]{");
						buffer.append(texttt(maskLaTeXspecialSymbols(id)));
						buffer.append('}');
						if (i < eventsInvolved.size() - 1)
							buffer.append(", ");
					}
					// buffer.append(" influence");
					// if (eventsInvolved.size() == 1)
					// buffer.append('s');
					// buffer.append(" the rate of change of this species.");
					buffer.newLine();
				}

				/*
				 * Rules
				 */

				Vector<String> rulesInvolved = new Vector<String>();
				for (i = 0; i < model.getNumRules(); i++) {
					Rule rule = model.getRule(i);
					if (rule instanceof AlgebraicRule) {
						if (contains(species.getId(), rule.getMath()))
							rulesInvolved.add(rule.getId());
					} else if (rule.getVariable().equals(species.getId()))
						rulesInvolved.add(rule.getId());
				}
				if (rulesInvolved.size() > 0) {
					buffer.append("\\item[Involved in rule");
					if (rulesInvolved.size() > 1)
						buffer.append('s');
					buffer.append("] ");
					for (i = 0; i < rulesInvolved.size(); i++) {
						String id = rulesInvolved.get(i);
						buffer.append("\\hyperref[rule" + id + "]{");
						buffer.append(texttt(maskLaTeXspecialSymbols(id)));
						buffer.append('}');
						if (i < rulesInvolved.size() - 1)
							buffer.append(", ");
					}
					// buffer.append(" determine");
					// if (rulesInvolved.size() == 1)
					// buffer.append('s');
					// buffer.append(" the rate of change of this species.");
					buffer.newLine();
				}
				buffer.append(descriptionEnd);

				/*
				 * Derived Rate of Change
				 */

				StringWriter equation = new StringWriter();
				BufferedWriter equationBW = new BufferedWriter(equation);
				ASTNode ast;
				for (i = 0; i < productsReaction[(int) speciesIndex].size(); i++) {
					reactionIndex = productsReaction[(int) speciesIndex].get(i);
					Reaction r = model.getReaction(reactionIndex - 1);
					notSubstancePerTimeUnit = notExistingKineticLaw = false;
					if (r != null) {
						KineticLaw kl = r.getKineticLaw();
						if (kl != null)
							notSubstancePerTimeUnit = !isVariantOfSubstancePerTime(kl
									.getDerivedUnitDefinition());
						else
							notExistingKineticLaw = true;
					} else
						notExistingKineticLaw = true;
					equationBW.flush();
					if (equation.getBuffer().length() > 0)
						equationBW.append(" + ");
					SpeciesReference product = r.getProduct(species.getId());
					if (product.isSetStoichiometryMath()) {
						ast = product.getStoichiometryMath().getMath();
						if (ast.getType() == AST_PLUS
								|| ast.getType() == AST_MINUS) {
							equationBW.append("\\left(");
							equationBW.append(toLaTeX(model, ast));
							equationBW.append("\\right)");
						} else
							equationBW.append(toLaTeX(model, ast));
					} else {
						double doubleStoch = product.getStoichiometry();
						if (doubleStoch != 1d)
							equationBW.append(format(doubleStoch).toString()
									.replaceAll("\\$", ""));
					}
					formatVelocity(reactionIndex, notSubstancePerTimeUnit,
							notExistingKineticLaw, equationBW);
				}
				for (i = 0; i < reactantsReaction[(int) speciesIndex].size(); i++) {
					reactionIndex = reactantsReaction[(int) speciesIndex]
							.get(i) - 1;
					Reaction r = model.getReaction(reactionIndex);
					notSubstancePerTimeUnit = notExistingKineticLaw = false;
					if (r != null) {
						KineticLaw kl = r.getKineticLaw();
						if (kl != null) {
							notSubstancePerTimeUnit = !isVariantOfSubstancePerTime(kl
									.getDerivedUnitDefinition());
						} else
							notExistingKineticLaw = true;
					} else
						notExistingKineticLaw = true;

					SpeciesReference reactant = r.getReactant(species.getId());
					equationBW.append('-');
					if (reactant.isSetStoichiometryMath()) {
						ast = reactant.getStoichiometryMath().getMath();
						if (ast.getType() == AST_PLUS
								|| ast.getType() == AST_MINUS) {
							equationBW.append("\\left(");
							equationBW.append(toLaTeX(model, ast));
							equationBW.append("\\right)");
						} else
							equationBW.append(toLaTeX(model, ast));
					} else {
						double doubleStoch = reactant.getStoichiometry();
						if (doubleStoch != 1.0)
							equationBW.append(format(doubleStoch).toString()
									.replaceAll("\\$", ""));
					}
					formatVelocity(reactionIndex + 1, notSubstancePerTimeUnit,
							notExistingKineticLaw, equationBW);
				}
				equationBW.close();

				int numReactionsInvolved = productsReaction[(int) speciesIndex]
						.size()
						+ reactantsReaction[(int) speciesIndex].size();

				if (species.getBoundaryCondition()) {
					if (species.getConstant()) {
						// never changes
						if (numReactionsInvolved > 0) {
							formatReactionsInvolved(model, speciesIndex,
									reactantsReaction, productsReaction, buffer);
							buffer.append(", which do");
							if (numReactionsInvolved == 1)
								buffer.append("es");
							buffer.append(" not influence its rate of change ");
							buffer.append("because this constant species is ");
							buffer.append("on the boundary of the reaction");
							buffer.append(" system:");
						}
						buffer.append(eqBegin);
						buffer.append("\\frac{\\mathrm d}{\\mathrm dt} ");
						buffer.append(getNameOrID(species, true));
						buffer.append(" = 0");
						buffer.append(eqEnd);
						if ((rulesInvolved.size() > 0)
								|| (eventsInvolved.size() > 0)) {
							buffer
									.append("This species' quantity is affected by ");
							if (rulesInvolved.size() > 0) {
								buffer.append(getWordForNumber(rulesInvolved
										.size()));
								buffer.append(" rule");
								if (rulesInvolved.size() > 1)
									buffer.append('s');
								if (eventsInvolved.size() > 0)
									buffer.append(" and");
							}
							if (eventsInvolved.size() > 0) {
								buffer.append(getWordForNumber(eventsInvolved
										.size()));
								buffer.append(" event");
								if (eventsInvolved.size() > 1)
									buffer.append('s');
							}
							buffer
									.append(". Please verify this SBML document.");
							buffer.newLine();
						}
					} else {
						// changes only due to rules and events
						if (numReactionsInvolved > 0)
							formatReactionsInvolved(model, speciesIndex,
									reactantsReaction, productsReaction, buffer);
						if ((rulesInvolved.size() > 0)
								|| (eventsInvolved.size() > 0)) {
							if (numReactionsInvolved == 1)
								buffer.append(". Not this but ");
							else if (numReactionsInvolved > 1)
								buffer.append(". Not these but ");
							if (rulesInvolved.size() > 0) {
								String number = getWordForNumber(rulesInvolved
										.size());
								if (numReactionsInvolved == 0) {
									char first = number.charAt(0);
									if (!Character.isDigit(first))
										first = Character.toUpperCase(first);
									if (number.length() == 1)
										number = new String(
												new char[] { first });
									else
										number = first + number.substring(1);
								}
								buffer.append(number);
								buffer.append(" rule");
								if (rulesInvolved.size() > 1)
									buffer.append('s');
								if (eventsInvolved.size() > 0)
									buffer.append(" together with ");
							}
							if (eventsInvolved.size() > 0) {
								String number = getWordForNumber(eventsInvolved
										.size());
								if (numReactionsInvolved == 0) {
									char first = number.charAt(0);
									if (!Character.isDigit(first))
										first = Character.toUpperCase(first);
									if (number.length() == 1)
										number = new String(
												new char[] { first });
									else
										number = first + number.substring(1);
								}
								buffer.append(getWordForNumber(eventsInvolved
										.size()));
								buffer.append(" event");
								if (eventsInvolved.size() > 1)
									buffer.append('s');
							}
							if (rulesInvolved.size() == 0)
								buffer.append(" influence");
							else
								buffer.append(" determine");
							if (eventsInvolved.size() + rulesInvolved.size() == 1)
								buffer.append('s');
							buffer.append(" the species' quantity");
							if (numReactionsInvolved > 0) {
								buffer
										.append(" because this species is on the");
								buffer
										.append(" boundary of the reaction system");
							}
							buffer.append('.');
						} else {
							if (numReactionsInvolved > 0) {
								buffer.append(", which do");
								if (numReactionsInvolved == 1)
									buffer.append("es");
								buffer
										.append(" not influence its rate of change");
								buffer
										.append(" because this species is on the");
								buffer
										.append(" boundary of the reaction system:");
							}
							buffer.append(eqBegin);
							buffer.append("\\frac{\\mathrm d}{\\mathrm dt} ");
							buffer.append(getNameOrID(species, true));
							buffer.append(" = 0");
							buffer.append(eqEnd);
						}
					}
				} else {
					if (species.getConstant()) {
						// never changes, cannot be reactant or product and no
						// rules
						if ((rulesInvolved.size() == eventsInvolved.size())
								&& (numReactionsInvolved == 0)
								&& (numReactionsInvolved == rulesInvolved
										.size())) {
							buffer.append(eqBegin);
							buffer.append("\\frac{\\mathrm d}{\\mathrm dt} ");
							buffer.append(getNameOrID(species, true));
							buffer.append(" = 0");
							buffer.append(eqEnd);
						} else {
							buffer
									.append("As this species is constant and its");
							buffer.append(" boundary condition is ");
							buffer.append(texttt("false"));
							buffer.append(" it cannot be involved in");
							boolean comma = false;
							if (rulesInvolved.size() > 0) {
								buffer.append(" any rules");
								comma = true;
							}
							if (eventsInvolved.size() > 0) {
								if (comma)
									buffer.append(", ");
								else
									comma = true;
								buffer.append(" any events");
							}
							if (numReactionsInvolved > 0) {
								if (comma)
									buffer.append(" or");
								buffer.append(" any reactions");
							}
							buffer
									.append(". Please verify this SBML document.");
						}
					} else {
						// changes by reactions xor rules; and events
						if (rulesInvolved.size() > 0) {
							boolean allAlgebraic = true;
							for (Iterator<String> iterator = rulesInvolved
									.iterator(); iterator.hasNext();)
								if (!(model.getRule(iterator.next()) instanceof AlgebraicRule))
									allAlgebraic = false;
							String number = getWordForNumber(rulesInvolved
									.size());
							if (numReactionsInvolved > 0) {
								formatReactionsInvolved(model, speciesIndex,
										reactantsReaction, productsReaction,
										buffer);
								buffer.append(" and is also involved in ");
							} else {
								char first = number.charAt(0);
								if (!Character.isDigit(first))
									first = Character.toUpperCase(first);
								if (number.length() == 1)
									number = new String(new char[] { first });
								else
									number = first + number.substring(1);
							}
							buffer.append(number);
							if (allAlgebraic)
								buffer.append(" algebraic");
							buffer.append(" rule");
							if (rulesInvolved.size() > 1)
								buffer.append('s');
							if (numReactionsInvolved == 0) {
								buffer.append(" determine");
								if (rulesInvolved.size() == 1)
									buffer.append('s');
								buffer.append(" this species' quantity.");
							} else if (!allAlgebraic) {
								buffer.append(". Please verify this SBML ");
								buffer.append("document.");
							} else {
								buffer.append('.');
								buffer.append(eqBegin);
								buffer
										.append("\\frac{\\mathrm d}{\\mathrm dt} ");
								buffer.append(getNameOrID(species, true));
								buffer.append(" = ");
								if (equation.getBuffer().length() > 0)
									buffer.append(equation.getBuffer());
								else
									buffer.append('0');
								buffer.append(eqEnd);
							}
							buffer.newLine();
						} else {
							if (numReactionsInvolved == 0) {
								buffer.append("This species does not take");
								buffer.append(" part in any reactions. ");
								buffer.append("Its quantity does hence not ");
								buffer.append("change over time:");
							}
							buffer.append(eqBegin);
							buffer.append("\\frac{\\mathrm d}{\\mathrm dt} ");
							buffer.append(getNameOrID(species, true));
							buffer.append(" = ");
							buffer
									.append((equation.getBuffer().length() > 0) ? equation
											.getBuffer()
											: "0");
							buffer.append(eqEnd);
						}
						if (eventsInvolved.size() > 0) {
							buffer.append("Furthermore, ");
							buffer.append(getWordForNumber(eventsInvolved
									.size()));
							buffer.append(" event");
							if (eventsInvolved.size() > 1)
								buffer.append('s');
							buffer.append(" influence");
							if (eventsInvolved.size() == 1)
								buffer.append('s');
							buffer.append(" this species' rate of change.");
						}
					}
				}
			}
			buffer.newLine();
		}
	}

	/**
	 * 
	 * @param a
	 * @param buffer
	 * @throws IOException
	 */
	private void format(InitialAssignment a, BufferedWriter buffer)
			throws IOException {
		buffer.append(descriptionBegin);
		format(a, buffer, true);
		buffer.append("\\item[Derived unit] ");
		if (a.containsUndeclaredUnits())
			buffer.append("contains undeclared units");
		else {
			buffer.append('$');
			buffer.append(format(a.getDerivedUnitDefinition()));
			buffer.append('$');
		}
		buffer.newLine();
		buffer.append("\\item[Math] $");
		buffer.append(toLaTeX(a.getModel(), a.getMath()));
		buffer.append('$');
		buffer.newLine();
		buffer.append(descriptionEnd);
	}

	/**
	 * Creates a subsection with all necessary information about one reaction.
	 * 
	 * @param r
	 * @param reactionIndex
	 * @return
	 * @throws IOException
	 */
	private StringBuffer format(Reaction r, long reactionIndex)
			throws IOException {
		long i;
		StringWriter reactString = new StringWriter();
		reactString.append(newLine);
		reactString.append("\\subsection{Reaction ");
		reactString.append(texttt(maskLaTeXspecialSymbols(r.getId())));
		reactString.append('}');
		reactString.append(newLine);
		reactString.append("This is a");

		if (!r.getReversible())
			reactString.append(r.getFast() ? " fast ir" : "n ir");
		else
			reactString.append(r.getFast() ? " fast " : " ");
		reactString.append("reversible reaction.");

		int hasSBOReactants = 0, hasSBOProducts = 0, hasSBOModifiers = 0;
		for (i = 0; i < r.getNumReactants(); i++)
			if (r.getReactant(i).isSetSBOTerm())
				hasSBOReactants++;
		for (i = 0, hasSBOProducts = 0; i < r.getNumProducts(); i++)
			if (r.getProduct(i).isSetSBOTerm())
				hasSBOProducts++;
		for (i = 0, hasSBOModifiers = 0; i < r.getNumModifiers(); i++)
			if (r.getModifier(i).isSetSBOTerm())
				hasSBOModifiers++;
		if (r.isSetName() || r.isSetNotes() || r.isSetSBOTerm()
				|| (hasSBOReactants + hasSBOProducts + hasSBOModifiers > 0)) {
			reactString.append(descriptionBegin);
			BufferedWriter bw = new BufferedWriter(reactString);
			format(r, bw, true);
			bw.close();
			if (hasSBOReactants > 0) {
				reactString.append("\\item[Reactant");
				if (hasSBOReactants > 1)
					reactString.append('s');
				reactString.append(" with SBO annotation] ");
				for (i = 0; i < r.getNumReactants(); i++) {
					SpeciesReference reactant = r.getReactant(i);
					if (r.getReactant(i).isSetSBOTerm()) {
						reactString
								.append(texttt(maskLaTeXspecialSymbols(reactant
										.getSpecies())));
						reactString.append(" (");
						reactString.append(getSBOnumber(reactant.getSBOTerm()));
						sboTerms.add(Integer.valueOf(reactant.getSBOTerm()));
						reactString.append(')');
						if (--hasSBOReactants > 0)
							reactString.append(", ");
					}
				}
			}
			if (hasSBOProducts > 0) {
				reactString.append("\\item[Product");
				if (hasSBOProducts > 1)
					reactString.append('s');
				reactString.append(" with SBO annotation] ");
				for (i = 0; i < r.getNumProducts(); i++) {
					SpeciesReference product = r.getProduct(i);
					if (r.getProduct(i).isSetSBOTerm()) {
						reactString
								.append(texttt(maskLaTeXspecialSymbols(product
										.getSpecies())));
						reactString.append(" (");
						reactString.append(getSBOnumber(product.getSBOTerm()));
						sboTerms.add(Integer.valueOf(product.getSBOTerm()));
						reactString.append(')');
						if (--hasSBOProducts > 0)
							reactString.append(", ");
					}
				}
			}

			if (r.getListOfModifiers().size() > 0) {
				if (hasSBOModifiers > 0) {
					reactString.append("\\item[Modifier");
					if (hasSBOModifiers > 1)
						reactString.append('s');
					reactString.append(" with SBO annotation] ");
					for (i = 0; i < r.getNumModifiers(); i++) {
						ModifierSpeciesReference m = r.getModifier(i);
						if (m.isSetSBOTerm()) {
							reactString.append(" (");
							reactString.append(getSBOnumber(m.getSBOTerm()));
							reactString.append(" ");
							reactString.append(SBOParser.getSBOTermName(m
									.getSBOTerm()));
							sboTerms.add(Integer.valueOf(m.getSBOTerm()));
							reactString.append(')');
							if (--hasSBOModifiers > 0)
								reactString.append(", ");
						}
					}
				}
			}
			reactString.append(descriptionEnd);
		}

		reactString.append("\\subsubsection*{Reaction equation}");
		reactString.append(newLine);
		reactString.append("\\reaction{");
		reactString.append(reactionEquation(r));
		reactString.append('}');
		reactString.append(newLine);

		/*
		 * Table for the reactants and products
		 */
		String headLine = "", head = "@{}", idAndNameColumn;
		double nameWidth = 3;
		double idWidth = nameWidth / 2;
		if (paperSize.equals("letter") || paperSize.equals("a4"))
			idAndNameColumn = "p{" + idWidth + "cm}p{" + nameWidth + "cm}";
		else {
			int columns = 0;
			if (r.getNumReactants() > 0)
				columns += 2;
			if (r.getNumModifiers() > 0)
				columns += 2;
			if (r.getNumProducts() > 0)
				columns += 2;
			switch (columns) {
			case 2:
				idWidth = 0.3;
				break;
			case 4:
				idWidth = 0.15;
				break;
			case 6:
				idWidth = 0.1;
				break;
			default:
				idWidth = 0;
				break;
			}
			nameWidth = idWidth * 2;
			idAndNameColumn = "p{" + idWidth + "\\textwidth}p{" + nameWidth
					+ "\\textwidth}";
		}
		int cols = 0;
		if (r.getNumReactants() > 0) {
			headLine = "\\multicolumn{2}{c";
			head += idAndNameColumn;
			if ((r.getNumProducts() > 0) || (r.getNumModifiers() > 0)) {
				headLine += "|}{Reactants}&";
				head += '|';
			} else
				headLine += "}{Reactants}";
			cols++;
		}
		if (r.getNumModifiers() > 0) {
			headLine += "\\multicolumn{2}{c";
			head += idAndNameColumn;
			if (r.getNumProducts() > 0) {
				headLine += "|}{Modifiers}&";
				head += '|';
			} else
				headLine += "}{Modifiers}";
			cols++;
		}
		if (r.getNumProducts() > 0) {
			headLine += "\\multicolumn{2}{c}{Products}";
			head += idAndNameColumn;
			cols++;
		}
		headLine += lineBreak;
		headLine += "id&name";
		for (i = 1; i < cols; i++)
			headLine += "&id&name";
		reactString.append(longtableHead(head + "@{}",
				"Overview of participating species.", headLine));
		for (i = 0; i < Math.max(r.getNumReactants(), Math.max(r
				.getNumProducts(), r.getNumModifiers())); i++) {
			Species s;
			if (r.getNumReactants() > 0) {
				if (i < r.getNumReactants()) {
					s = r.getModel().getSpecies(r.getReactant(i).getSpecies());
					reactString
							.append(texttt(maskLaTeXspecialSymbols(s.getId())));
					reactString.append('&');
					reactString.append(maskLaTeXspecialSymbols(s.getName()));
					/*
					 * reactString.append('&');
					 * reactString.append(s.isSetSBOTerm() ? getSBOnumber(s
					 * .getSBOTerm()) : " ");
					 */
				} else
					reactString.append('&');
				if ((r.getNumModifiers() > 0) || (r.getNumProducts() > 0))
					reactString.append('&');
			}
			if (r.getNumModifiers() > 0) {
				if (i < r.getNumModifiers()) {
					s = r.getModel().getSpecies(r.getModifier(i).getSpecies());
					reactString
							.append(texttt(maskLaTeXspecialSymbols(s.getId())));
					reactString.append('&');
					reactString.append(maskLaTeXspecialSymbols(s.getName()));
					/*
					 * reactString.append('&');
					 * reactString.append(s.isSetSBOTerm() ? getSBOnumber(s
					 * .getSBOTerm()) : " ");
					 */
				}
				if (r.getNumProducts() > 0)
					reactString.append('&');
			}
			if (r.getNumProducts() > 0) {
				if (i < r.getNumProducts()) {
					s = r.getModel().getSpecies(r.getProduct(i).getSpecies());
					reactString
							.append(texttt(maskLaTeXspecialSymbols(s.getId())));
					reactString.append('&');
					reactString.append(maskLaTeXspecialSymbols(s.getName()));
					/*
					 * reactString.append('&');
					 * reactString.append(s.isSetSBOTerm() ? getSBOnumber(s
					 * .getSBOTerm()) : " ");
					 */
				} else
					reactString.append('&');
			}
			reactString.append(lineBreak);
		}
		reactString.append(bottomrule);

		reactString.append(newLine);
		reactString.append("\\subsubsection*{Kinetic Law}");
		reactString.append(newLine);

		StringWriter localParameters = new StringWriter();
		if (r.getKineticLaw() != null) {
			KineticLaw kin = r.getKineticLaw();
			reactString.append(descriptionBegin);
			BufferedWriter pBuffer = new BufferedWriter(reactString);
			format(kin, pBuffer, true);
			pBuffer.close();
			UnitDefinition ud = kin.getDerivedUnitDefinition();
			reactString.append("\\item[Derived unit] ");
			if (ud.getListOfUnits().size() == 0)
				reactString.append("not available");
			else if (kin.containsUndeclaredUnits())
				reactString.append("contains undeclared units");
			else {
				reactString.append('$');
				UnitDefinition.simplify(ud);
				reactString.append(format(ud));
				reactString.append('$');
			}
			reactString.append(newLine);
			reactString.append(descriptionEnd);
			reactString.append(eqBegin);
			reactString.append("v_{" + (reactionIndex + 1) + "}=");
			if (kin.getMath() != null)
				reactString.append(toLaTeX(r.getModel(), kin.getMath()));
			else
				reactString.append("\\text{no mathematics specified}");
			pBuffer = new BufferedWriter(localParameters);
			if (r.getKineticLaw().getNumParameters() > 0)
				format(r.getKineticLaw().getListOfParameters(), pBuffer, false);
			pBuffer.close();
		} else {
			reactString.append(eqBegin);
			reactString.append("v_{" + (reactionIndex + 1) + "}=");
			reactString.append("\\text{no kinetic law specified}");
		}
		reactString.append(newLine);
		reactString.append("\\label{v");
		reactString.append(Long.toString(reactionIndex + 1));
		reactString.append('}');
		reactString.append(eqEnd);
		reactString.append(localParameters.getBuffer());

		return reactString.getBuffer();
	}

	/**
	 * 
	 * @param def
	 * @param buffer
	 * @throws IOException
	 */
	private void format(FunctionDefinition def, BufferedWriter buffer)
			throws IOException {
		buffer.append(descriptionBegin);
		format(def, buffer, true);
		if ((def.getNumArguments() > 0) || (def.getBody() != null)
				|| def.isSetMath()) {
			if (def.getNumArguments() > 0) {
				buffer.append("\\item[Argument");
				buffer.append(def.getNumArguments() > 1 ? "s] " : "] ");
				for (long j = 0; j < def.getNumArguments(); j++) {
					buffer.append('$');
					buffer.append(toLaTeX(def.getModel(), def.getArgument(j)));
					buffer.append('$');
					if (j < def.getNumArguments() - 1)
						buffer.append(", ");
				}
				buffer.newLine();
				if (def.getBody() != null) {
					buffer.append("\\item[Mathematical Expression]");
					buffer.append(eqBegin);
					buffer.append(toLaTeX(def.getModel(), def.getBody()));
					buffer.append(eqEnd);
				}
			} else if (def.isSetMath()) {
				buffer.append("\\item[Mathematical Formula]");
				buffer.append(eqBegin);
				buffer.append(getNameOrID(def, true));
				buffer.append(toLaTeX(def.getModel(), def.getMath()));
				buffer.append(eqEnd);
			}
		}
		buffer.append(descriptionEnd);
	}

	/**
	 * 
	 * @param rl
	 * @param buffer
	 * @throws IOException
	 */
	private void format(Rule rl, BufferedWriter buffer) throws IOException {
		buffer.append("Rule ");
		boolean hasId = false;
		if ((rl.isSetId()) && (rl.getId().length() > 0)) {
			hasId = true;
			buffer.append(texttt(maskLaTeXspecialSymbols(rl.getId())));
		}
		if ((rl.isSetName()) && (rl.getName().length() > 0)) {
			if (hasId)
				buffer.append(" (");
			buffer.append(maskLaTeXspecialSymbols(rl.getName()));
			if (hasId)
				buffer.append(')');
		}
		if (rl.isSetSBOTerm()) {
			buffer.append(" has the SBO reference ");
			buffer.append(getSBOnumber(rl.getSBOTerm()));
			sboTerms.add(Integer.valueOf(rl.getSBOTerm()));
			buffer.append(" and");
		}
		buffer.append(" is a");
		if (rl.isAlgebraic()) {
			buffer.append("n algebraic rule");
			buffer.append(eqBegin);
			buffer.append(toLaTeX(rl.getModel(), rl.getMath()));
			buffer.append("\\equiv 0");
			buffer.append(eqEnd);
		} else if (rl.isAssignment()) {
			buffer.append("n assignment rule for ");
			Model model = rl.getModel();
			String id = rl.getVariable();
			if (model.getSpecies(id) != null) {
				buffer.append("species ");
				buffer.append(texttt(maskLaTeXspecialSymbols(id)));
				buffer.append(':');
				buffer.append(eqBegin);
				Species species = model.getSpecies(id);
				if (species.getHasOnlySubstanceUnits())
					buffer.append('[');
				buffer.append(mathtt(maskLaTeXspecialSymbols(id)));
				if (species.getHasOnlySubstanceUnits())
					buffer.append(']');
			} else if (model.getCompartment(id) != null) {
				buffer.append("compartment ");
				buffer.append(texttt(maskLaTeXspecialSymbols(id)));
				buffer.append(':');
				buffer.append(eqBegin);
				buffer.append(getSize(model.getCompartment(id)));
			} else {
				buffer.append("parameter ");
				buffer.append(texttt(maskLaTeXspecialSymbols(id)));
				buffer.append(':');
				buffer.append(eqBegin);
				buffer.append(mathtt(maskLaTeXspecialSymbols(id)));
			}
			buffer.append(" = ");
			buffer.append(toLaTeX(model, rl.getMath()));
			buffer.append(eqEnd);
		} else {
			buffer.append(" rate rule for ");
			boolean hasOnlySubstanceUnits = false;
			if (rl.getModel().getSpecies(rl.getVariable()) != null) {
				buffer.append("species ");
				hasOnlySubstanceUnits = rl.getModel().getSpecies(
						rl.getVariable()).getHasOnlySubstanceUnits();
			} else if (rl.getModel().getCompartment(rl.getVariable()) != null)
				buffer.append("compartment ");
			else
				buffer.append("parameter ");
			buffer.append(texttt(maskLaTeXspecialSymbols(rl.getVariable())));
			buffer.append(':');
			buffer.append(eqBegin);
			buffer.append("\\frac{\\mathrm d}{\\mathrm dt} ");
			if (hasOnlySubstanceUnits)
				buffer.append('[');
			if (rl.getModel().getCompartment(rl.getVariable()) != null)
				buffer.append(getSize(rl.getModel().getCompartment(
						rl.getVariable())));
			else
				buffer
						.append(mathtt(maskLaTeXspecialSymbols(rl.getVariable())));
			if (hasOnlySubstanceUnits)
				buffer.append(']');
			buffer.append(" = ");
			buffer.append(toLaTeX(rl.getModel(), rl.getMath()));
			buffer.append(eqEnd);
		}
		if (rl.isSetNotes()
				|| ((rl.getDerivedUnitDefinition().getNumUnits() > 0) && !rl
						.containsUndeclaredUnits())) {
			buffer.append(descriptionBegin);
			if ((rl.getDerivedUnitDefinition().getNumUnits() > 0)
					&& !rl.containsUndeclaredUnits()) {
				buffer.append("\\item[Derived unit] $");
				buffer.append(format(rl.getDerivedUnitDefinition()));
				buffer.append('$');
				buffer.newLine();
			}
			if (rl.isSetNotes()) {
				buffer.append("\\item[Notes] ");
				buffer.append(formatHTML(rl.getNotesString()));
			}
			if ((rl.getNumCVTerms() > 0) && includeMIRIAM) {
				buffer.append("\\item[Annotation] ");
				for (long i = 0; i < rl.getNumCVTerms(); i++)
					format(rl.getCVTerm(i), buffer);
			}
			buffer.append(descriptionEnd);
		}
	}

	/**
	 * Returns a mathematical formula if stoichiometric math is used or the
	 * formated stoichiometric coefficient of the given SpeciesReference. Be
	 * aware that dollar symbols may be set at the beginning and the end of the
	 * stoichiometric coefficient/mathematical formula if necessary. If already
	 * using math mode please remove these dollar symbols.
	 * 
	 * @param spec
	 * @return
	 * @throws IOException
	 */
	private StringBuffer formatStoichiometry(SpeciesReference spec)
			throws IOException {
		StringWriter sw = new StringWriter();
		if (spec.isSetStoichiometryMath()) {
			sw.append('$');
			sw.append(toLaTeX(spec.getModel(), spec.getStoichiometryMath()
					.getMath()));
			sw.append('$');
		} else if (spec.getStoichiometry() != 1d)
			sw.append(format(spec.getStoichiometry()));
		sw.close();
		return sw.getBuffer();
	}

	/**
	 * This method returns a <code>StringBuffer</code> representing a properly
	 * LaTeX formatted number. However, if the <code>double</code> argument
	 * contains "Exx" (power of ten), then the returned value starts and ends
	 * with a dollar symbol.
	 * 
	 * @param value
	 * @return
	 */
	private StringBuffer format(double value) {
		StringBuffer sb = new StringBuffer();
		String val = Double.toString(value);
		if (val.contains("E")) {
			String split[] = val.split("E");
			val = "10^{" + format(Double.parseDouble(split[1])) + "}";
			if (split[0].equals("-1.0"))
				val = "-" + val;
			else if (!split[0].equals("1.0"))
				val = format(Double.parseDouble(split[0])) + "\\cdot " + val;
			sb.append('$' + val + '$');
		} else if (value - ((int) value) == 0)
			sb.append(((int) value));
		else
			sb.append(val);
		return sb;
	}

	/**
	 * This method decides if brakets are to be set. The symbol is a
	 * mathematical operator, e.g., plus, minus, multiplication etc. in LaTeX
	 * syntax (for instance
	 * 
	 * <pre>
	 * \cdot
	 * </pre>
	 * 
	 * ). It simply counts the number of descendants on the left and the right
	 * hand side of the symbol.
	 * 
	 * @param astnode
	 * @param model
	 * @param symbol
	 * @return
	 * @throws IOException
	 */
	private StringBuffer mathematicalOperation(ASTNode astnode, Model model,
			String symbol) throws IOException {
		StringBuffer value = new StringBuffer();
		if (1 < astnode.getLeftChild().getNumChildren())
			value.append("\\left(");
		value.append(toLaTeX(model, astnode.getLeftChild()));
		if (1 < astnode.getLeftChild().getNumChildren())
			value.append("\\right)");
		value.append(symbol);
		if (1 < astnode.getRightChild().getNumChildren())
			value.append("\\left(");
		value.append(toLaTeX(model, astnode.getRightChild()));
		if (1 < astnode.getRightChild().getNumChildren())
			value.append("\\right)");
		return value;
	}

	/**
	 * This method writes the foot of a LaTeX document.
	 * 
	 * @param doc
	 * @param buffer
	 * @throws IOException
	 */
	private void documentFoot(SBMLDocument doc, BufferedWriter buffer)
			throws IOException {
		if (sboTerms.size() > 0) {
			int sbo[] = new int[sboTerms.size()], j = 0, i = 0;
			for (Iterator<Integer> iterator = sboTerms.iterator(); iterator
					.hasNext(); j++)
				sbo[j] = iterator.next().intValue();
			Arrays.sort(sbo);
			String sboName[] = new String[sboTerms.size()];
			for (i = 0; i < sbo.length; i++)
				sboName[i] = getSBOnumber(sbo[i]) + " "
						+ SBOParser.getSBOTermName(sbo[i]) + ":";
			buffer.newLine();
			buffer
					.append("\\section{Glossary of Systems Biology Ontology Terms}");
			buffer.append("\\label{sec:glossary}");
			buffer.append(descriptionBegin);
			for (j = 0; j < sbo.length; j++) {
				sboName[j] = sboName[j].replaceAll("\\\\,", ",").replaceAll(
						"\\\\n", " ").replaceAll("\\\\:", ":").replaceAll(
						"\\\\\"", "\"").trim();
				if (sboName[j].endsWith("\"") && !sboName[j].startsWith("\""))
					sboName[j] = sboName[j].substring(0,
							sboName[j].length() - 2);
				sboName[j] = maskLaTeXspecialSymbols(sboName[j]);
				String def = SBOParser.getSBOTermDef(sbo[j]).replaceAll(
						"\\\\,", ",").replaceAll("\\\\n", " ").replaceAll(
						"\\\\:", ":").replaceAll("\\\\\"", "\"").trim();
				if (def.endsWith("\"") && !def.startsWith("\""))
					def = def.substring(0, def.length() - 2);
				def = maskLaTeXspecialSymbols(def);
				boolean start = true;
				for (i = 0; i < sboName[j].length(); i++)
					if (sboName[j].charAt(i) == '"')
						if (start) {
							if (i > 0)
								sboName[j] = sboName[j].substring(0, i - 1)
										+ " ``" + sboName[j].substring(i + 1);
							else
								sboName[j] = "``" + sboName[j].substring(1);
							start = false;
						} else
							start = true;
				start = true;
				for (i = 0; i < def.length(); i++)
					if (def.charAt(i) == '"')
						if (start) {
							if (i > 0)
								def = def.substring(0, i - 1) + " ``"
										+ def.substring(i + 1);
							else
								def = "``" + def.substring(1);
							start = false;
						} else
							start = true;
				buffer.append(descriptionItem(sboName[j], def));
			}
			buffer.append(descriptionEnd);
		}
		buffer.append(imprint());
		buffer.append("\\end{document}");
		buffer.newLine();
	}

	private StringBuffer imprint() {
		StringBuffer impressum = new StringBuffer("\\begin{figure}[b!]");
		impressum.append(newLine);
		impressum.append("\\setlength{\\fboxrule}{.1cm}");
		impressum.append(newLine);
		impressum.append("\\setlength{\\fboxsep}{.3cm}");
		impressum.append(newLine);
		impressum.append("\\fcolorbox{lightgray}{white}{");
		impressum.append("\\begin{minipage}{.945\\textwidth}");
		impressum.append(newLine);
		impressum
				.append("\\footnotesize\\SBMLLaTeX{} was developed by Andreas ");
		impressum
				.append("Dr\\\"ager\\footnote{Center for Bioinformatics T\\\"ubingen (ZBIT), ");
		impressum
				.append("Germany}, Hannes Planatscher$^a$, Dieudonn\\'e M Wouamba$^a$, Adrian ");
		impressum
				.append("Schr\\\"oder$^a$, Michael Hucka\\footnote{California Institute of ");
		impressum
				.append("Technology, Beckman Institute BNMC, Pasadena, United States}, Lukas ");
		impressum
				.append("Endler\\footnote{European Bioinformatics Institute, Welcome Trust ");
		impressum
				.append("Genome Campus, Hinxton, United Kingdom}, Martin Golebiewski");
		impressum
				.append("\\footnote{Scientific Databases and Visualization Group, EML Research ");
		impressum
				.append("gGmbH, Schloss-Wolfsbrunnenweg} and Andreas Zell$^a$. Please see ");
		impressum
				.append("\\url{http://webservices.cs.uni-tuebingen.de/webservices} for more ");
		impressum.append("information.");
		impressum.append(newLine);
		impressum.append("\\end{minipage}}");
		impressum.append(newLine);
		impressum.append("\\end{figure}");
		impressum.append(newLine);
		return impressum;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.jcell.client.io.DisplaySBML#format(org.sbml.libsbml.ListOfEvents,
	 * java.io.BufferedWriter)
	 */

	/**
	 * This method writes the head of a LaTeX file.
	 * 
	 * @param doc
	 * @param buffer
	 * @throws IOException
	 */
	private void documentHead(SBMLDocument doc, BufferedWriter buffer)
			throws IOException {
		int i;
		Model model = doc.getModel();
		String title = "", titlePrefix = "";
		if (doc.isSetName()) {
			title = maskLaTeXspecialSymbols(doc.getName());
			titlePrefix = "Document name:";
		} else if (model != null) {
			if (model.isSetName()) {
				title = maskLaTeXspecialSymbols(model.getName());
				titlePrefix = "Model name:";
			}
			if ((title.length() == 0) && (model.isSetId())
					&& (model.getId().length() > 0)) {
				title = maskLaTeXspecialSymbols(model.getId());
				titlePrefix = "Model identifier:";
			}
		} else if (doc.isSetId() && (doc.getId().length() > 0)) {
			title = maskLaTeXspecialSymbols(doc.getId());
			titlePrefix = "Document identifier:";
		}
		if (title.length() == 0) {
			title = "Untitled";
			titlePrefix = "";
		} else
			titlePrefix += " ";
		buffer.append("\\documentclass[");
		buffer.append(Short.toString(fontSize));
		buffer.append("pt,twoside");
		if (titlepage)
			buffer.append(",titlepage");
		if (landscape)
			buffer.append(",landscape");
		buffer.append(',');
		buffer.append(paperSize);
		buffer.append("paper");
		if (!paperSize.equals("a4") || (fontSize < 10) || (12 < fontSize))
			buffer.append(",DIVcalc");
		buffer.append("]{scrartcl}");
		buffer.newLine();
		buffer.append("\\usepackage[dvipsnames,svgnames]{xcolor}");
		buffer.newLine();
		buffer.append("\\usepackage{ifpdf}");
		buffer.newLine();
		buffer.append("\\usepackage{scrpage2}");
		buffer.newLine();
		buffer.append("\\ifpdf");
		buffer.newLine();
		buffer.append("  \\usepackage[pdfpagemode={UseOutlines},");
		buffer.newLine();
		buffer.append("              pdftitle={" + titlePrefix + "\"" + title
				+ "\"},");
		buffer.newLine();
		buffer
				.append("              pdfauthor={Produced by SBML2LaTeX version 1.0beta},");
		buffer.newLine();
		buffer.append("              pdfsubject={SBML model summary},");
		buffer.newLine();
		buffer.append("              pdfkeywords={},");
		buffer.newLine();
		buffer.append("              pdfview={FitBH},");
		buffer.newLine();
		buffer.append("              plainpages={false},");
		buffer.newLine();
		buffer.append("              pdftex,");
		buffer.newLine();
		buffer.append("              colorlinks=true,");
		buffer.newLine();
		buffer.append("              pdfdisplaydoctitle=true,");
		buffer.newLine();
		buffer.append("              linkcolor=royalblue,");
		buffer.newLine();
		buffer.append("              bookmarks,");
		buffer.newLine();
		buffer.append("              bookmarksopen,");
		buffer.newLine();
		buffer.append("              bookmarksnumbered,");
		buffer.newLine();
		buffer.append("              pdfhighlight={/P},");
		buffer.newLine();
		buffer.append("              urlcolor={blue}]{hyperref}");
		buffer.newLine();
		buffer.append("  \\usepackage{pdflscape}");
		buffer.newLine();
		buffer.append("  \\pdfcompresslevel=9");
		buffer.newLine();
		buffer.append("  \\usepackage[pdftex]{graphicx}");
		buffer.newLine();
		buffer.append("\\else");
		buffer.newLine();
		buffer.append("  \\usepackage[plainpages={false}]{hyperref}");
		buffer.newLine();
		buffer.append("  \\usepackage{lscape}");
		buffer.newLine();
		buffer.append("  \\usepackage{graphicx}");
		buffer.newLine();
		buffer.append("\\fi");
		buffer.newLine();
		String packages[] = { "relsize", "mathptmx", "pifont", "textcomp",
				"longtable", "tabularx", "booktabs", "amsmath", "amsfonts",
				"amssymb", "mathtools", "ulem", "wasysym", "eurosym", "breqn",
				"breakurl", "flexisym", "rotating", "upgreek" };
		for (i = 0; i < packages.length; i++) {
			buffer.append("\\usepackage{");
			buffer.append(packages[i]);
			buffer.append('}');
			buffer.newLine();
		}
		packages = new String[] { "[english]{babel}", "[scaled=.9]{helvet}",
				"[english]{rccol}", "[version=3]{mhchem}" };
		for (i = 0; i < packages.length; i++) {
			buffer.append("\\usepackage");
			buffer.append(packages[i]);
			buffer.newLine();
		}
		/*
		 * if (!landscape && paperSize.equals("a4")) {
		 * buffer.append("\\usepackage{a4wide}"); buffer.newLine(); } else
		 */{
			buffer.append("\\usepackage{calc}");
			buffer.newLine();
			buffer.append("\\usepackage[paper=");
			buffer.append(paperSize);
			buffer.append("paper,landscape=");
			buffer.append(Boolean.toString(landscape));
			buffer.append(",centering]{geometry}");
			buffer.newLine();
		}
		buffer.newLine();
		buffer.append("\\definecolor{royalblue}{cmyk}{.93, .79, 0, 0}");
		buffer.newLine();
		// buffer.append("\\definecolor{grau}{gray}{0.7}");
		// buffer.newLine();
		buffer.append("\\definecolor{lightgray}{gray}{0.95}");
		buffer.newLine();
		buffer.append("\\addtokomafont{sectioning}{\\color{royalblue}}");
		// \definecolor{blue}{cmyk}{.93, .59, 0, 0}
		buffer.newLine();
		buffer.append("\\pagestyle{scrheadings}");
		buffer.newLine();
		buffer.append("\\newcommand{\\SBMLLaTeX}{{\\sffamily\\upshape");
		buffer.append("\\raisebox{-.35ex}{S\\hspace{-.425ex}BML}");
		buffer
				.append("\\hspace{-0.5ex}\\begin{rotate}{-17.5}\\raisebox{-.1ex}{2}");
		buffer.append("\\end{rotate}\\hspace{1ex}\\LaTeX}}");
		buffer.newLine();
		buffer.append("\\cfoot{\\textcolor{gray}{Produced by \\SBMLLaTeX}}");
		buffer.newLine();
		buffer.newLine();
		buffer.append("\\subject{SBML Model Report}");
		buffer.newLine();
		buffer.append("\\title{");
		buffer.append(titlePrefix);
		if (titlePrefix.contains("identified"))
			title = texttt(title).toString();
		else
			title = "``" + title + "\"";
		buffer.append(title);
		buffer.append('}');
		// buffer.append("}}}}");
		buffer.newLine();
		buffer.append("\\date{\\today}");
		buffer.newLine();
		buffer.append("\\author{");
		buffer.append("\\includegraphics[height=3.5ex]{" + logo + "}}");
		buffer.newLine();
		buffer
				.append("\\newcommand{\\numero}{N\\hspace{-0.075em}\\raisebox{0.25em}{\\relsize{-2}\\b{o}}}");
		buffer.newLine();
		buffer.append("\\newcommand{\\reaction}[1]{");
		buffer.append("\\begin{equation}\\ce{#1}\\end{equation}}");
		buffer.newLine();
		buffer
				.append("\\newcolumntype{C}[1]{>{\\centering\\arraybackslash}p{#1}}");
		buffer.newLine();
		if (!typeWriter) {
			buffer.append("\\urlstyle{same}");
			buffer.newLine();
		}
		buffer.newLine();
		buffer.append("\\begin{document}");
		buffer.newLine();
		buffer.append("\\maketitle");
		buffer.newLine();
		buffer.append("\\thispagestyle{scrheadings}");
		buffer.newLine();
	}

	/**
	 * Writes a document foot for the LaTeX Document for all objects derived
	 * from {@see ListOf}.
	 * 
	 * @param listOf
	 * @param buffer
	 * @throws IOException
	 */
	private void documentFoot(ListOf listOf, BufferedWriter buffer)
			throws IOException {
		if (listOf.size() == 0) {
			buffer.append("This list of ");
			buffer.append(listOf.getElementName());
			buffer.append(' ');
			boolean hasId = false;
			if (listOf.isSetId())
				buffer.append(texttt(maskLaTeXspecialSymbols(listOf.getId())));
			if (listOf.isSetName()) {
				if (hasId)
					buffer.append(" (");
				buffer.append(maskLaTeXspecialSymbols(listOf.getName()));
				if (hasId)
					buffer.append(") ");
				else
					buffer.append(' ');
			}
			buffer.append("does not contain any entries.");
		}
		documentFoot(listOf.getSBMLDocument(), buffer);
	}

	/**
	 * Creates a head for a longtable in LaTeX.
	 * 
	 * @param columnDef
	 *            without leading and ending brackets, e.g., "lrrc",
	 * @param caption
	 *            caption of this table without leading and ending brackets
	 * @param headLine
	 *            table head without leading and ending brackets and without
	 *            double backslashes at the end
	 * @return
	 */
	private StringBuffer longtableHead(String columnDef, String caption,
			String headLine) {
		StringBuffer buffer = new StringBuffer("\\begin{longtable}[h!]{");
		buffer.append(columnDef);
		buffer.append('}');
		buffer.append(newLine);
		buffer.append("\\caption{");
		buffer.append(caption);
		buffer.append("}");
		buffer.append("\\\\");
		StringBuffer head = new StringBuffer(toprule);
		head.append(headLine);
		head.append("\\\\");
		head.append(midrule);
		buffer.append(head);
		buffer.append("\\endfirsthead");
		// buffer.append(newLine);
		buffer.append(head);
		buffer.append("\\endhead");
		// buffer.append(bottomrule);
		// buffer.append("\\endlastfoot");
		buffer.append(newLine);
		return buffer;
	}

	/**
	 * Masks all special characters used by LaTeX with a backslash.
	 * 
	 * @param string
	 * @return
	 */
	private static String maskLaTeXspecialSymbols(String string) {
		return maskLaTeXspecialSymbols(string, true);
	}

	/**
	 * 
	 * @param string
	 * @param hyphen
	 *            if true a hyphen symbol is introduced at each position where a
	 *            special character has to be masked anyway.
	 * @return
	 */
	private static String maskLaTeXspecialSymbols(String string, boolean hyphen) {
		StringBuffer masked = new StringBuffer();
		for (int i = 0; i < string.length(); i++) {
			char atI = string.charAt(i);
			if ((atI == '_') || (atI == '\\') || (atI == '$') || (atI == '&')
					|| (atI == '#') || (atI == '{') || (atI == '}')
					|| (atI == '~') || (atI == '%')) {
				if ((i == 0) || (!hyphen))
					masked.append('\\');
				else if (hyphen && (string.charAt(i - 1) != '\\'))
					masked.append("\\-\\"); // masked.append('\\');
				// } else if ((atI == '[') || (atI == ']')) {
			}
			masked.append(atI);
		}
		return masked.toString().trim();
	}

	/**
	 * Returns the LaTeX code to set the given String in type writer font.
	 * 
	 * @param id
	 * @return
	 */
	private StringBuffer texttt(String id) {
		StringBuffer sb = new StringBuffer();
		if (typeWriter)
			sb.append("\\texttt{");
		sb.append(id);
		if (typeWriter)
			sb.append('}');
		return sb;
	}

	/**
	 * Returns the LaTeX code to set the given String in type writer font within
	 * a math environment.
	 * 
	 * @param id
	 * @return
	 */
	private StringBuffer mathtt(String id) {
		StringBuffer sb = new StringBuffer(typeWriter ? "\\mathtt{"
				: "\\mathrm{");
		sb.append(id);
		sb.append('}');
		return sb;
	}

	/**
	 * Creates a subsection for the given problem class.
	 * 
	 * @param listOfErrorIndices
	 *            A list containing indices of document errors.
	 * @param doc
	 *            The SBML document containing the problems
	 * @param title
	 *            The title of a subsection for the problem class.
	 * @param buffer
	 *            the writer
	 * @param messageType
	 *            An identifier, e.g., "Error" or "Problem" or "Information"
	 *            etc.
	 * @throws IOException
	 */
	private void problemMessage(Vector<Long> listOfErrorIndices,
			SBMLDocument doc, String title, BufferedWriter buffer,
			String messageType) throws IOException {
		buffer.append("\\subsection{");
		buffer.append(title);
		buffer.append('}');
		buffer.newLine();
		buffer.append("This SBML document contains ");
		buffer.append(getWordForNumber(listOfErrorIndices.size()));
		buffer.append(' ');
		buffer.append(title.startsWith("XML") ? title
				: firstLetterLowerCase(title));
		buffer.append('.');
		buffer.newLine();
		buffer.append(descriptionBegin);
		for (int i = 0; i < listOfErrorIndices.size(); i++) {
			SBMLError error = doc.getError(listOfErrorIndices.get(i)
					.longValue());
			buffer.append(descriptionItem(messageType + ' '
					+ Long.toString(error.getErrorId()), error.getMessage()));
		}
		buffer.append(descriptionEnd);
		buffer.newLine();
	}

	/**
	 * Creates a hyper link to the given target and the text to be visible in
	 * the document.
	 * 
	 * @param target
	 *            The target to which this link points to.
	 * @param text
	 *            The text to be written in the link.
	 * @return
	 */
	private StringBuffer href(String target, String text) {
		StringBuffer href = new StringBuffer("\\href{");
		href.append(target);
		href.append("}{");
		href.append(text);
		href.append('}');
		return href;
	}

	/**
	 * This method simplifies the process of creating descriptions. There is an
	 * item entry together with a description. No new line or space is needed
	 * for separation.
	 * 
	 * @param item
	 *            e.g., "my item"
	 * @param description
	 *            e.g., "my description"
	 * @return
	 */
	private StringBuffer descriptionItem(String item, String description) {
		StringBuffer itemBuffer = new StringBuffer("\\item[");
		itemBuffer.append(item);
		itemBuffer.append("] ");
		itemBuffer.append(description);
		itemBuffer.append(newLine);
		return itemBuffer;
	}

	/**
	 * This method returns a StringBuffer containing the reaction equation for
	 * the given reaction. Note that this equation has to be surrounded by a
	 * 
	 * <pre>
	 * \ce{...}
	 * </pre>
	 * 
	 * tag to be displayed in LaTeX.
	 * 
	 * @param r
	 * @return
	 * @throws IOException
	 */
	private StringBuffer reactionEquation(Reaction r) throws IOException {
		long i;
		StringBuffer reactString = new StringBuffer();
		if (r.getNumReactants() == 0)
			reactString.append("$\\emptyset$");
		else
			for (i = 0; i < r.getNumReactants(); i++) {
				if (r.getReactant(i) == null) {
					reactString
							.append("$\\text{invalid species reference for reactant ");
					reactString.append(getWordForNumber(i + 1));
					reactString.append("}$");
				} else {
					reactString.append(formatStoichiometry(r.getReactant(i)));
					reactString.append(" $");
					reactString.append(getNameOrID(r.getModel().getSpecies(
							r.getReactant(i).getSpecies()),
							printNameIfAvailable));
					reactString.append('$');
				}
				if (i < r.getNumReactants() - 1)
					reactString.append(" + ");
			}
		reactString.append(r.getReversible() ? " <=>" : " ->");
		if (r.getNumModifiers() > 0) {
			reactString.append("[\\text{");
			Species s = r.getModel().getSpecies(r.getModifier(0).getSpecies());
			if (s.isSetName() && printNameIfAvailable)
				reactString.append(s.getName());
			else
				reactString.append(texttt(maskLaTeXspecialSymbols(s.getId())));
			for (i = 1; i < r.getNumModifiers(); i++) {
				reactString.append(",\\;");
				s = r.getModel().getSpecies(r.getModifier(i).getSpecies());
				if (s.isSetName() && printNameIfAvailable)
					reactString.append(s.getName());
				else
					reactString
							.append(texttt(maskLaTeXspecialSymbols(s.getId())));
			}
			reactString.append("}] ");
		} else
			reactString.append(' ');
		if (r.getNumProducts() == 0)
			reactString.append("$\\emptyset$");
		else
			for (i = 0; i < r.getNumProducts(); i++) {
				if (r.getProduct(i) == null) {
					reactString
							.append("$\\text{invalid species reference for product ");
					reactString.append(getWordForNumber(i + 1));
					reactString.append("}$");
				} else {
					reactString.append(formatStoichiometry(r.getProduct(i)));
					reactString.append(" $");
					reactString.append(getNameOrID(r.getModel().getSpecies(
							r.getProduct(i).getSpecies()), true));
					reactString.append('$');
				}
				if (i < r.getNumProducts() - 1)
					reactString.append(" + ");
			}
		return reactString;
	}

	/**
	 * 
	 * @param c
	 * @return True if the given character is a vocal and false if it is a
	 *         consonant.
	 */
	private boolean isVocal(char c) {
		c = Character.toLowerCase(c);
		return (c == 'a') || (c == 'e') || (c == 'i') || (c == 'o')
				|| (c == 'u');
	}

	/**
	 * If the field printNameIfAvailable is false this method returns a the id
	 * of the given SBase. If printNameIfAvailable is true this method looks for
	 * the name of the given SBase and will return it.
	 * 
	 * @param sbase
	 *            the SBase, whose name or id is to be returned.
	 * @param mathMode
	 *            if true this method returns the name typesetted in mathmode,
	 *            i.e., mathrm for names and mathtt for ids, otherwise texttt
	 *            will be used for ids and normalfont (nothing) will be used for
	 *            names.
	 * @return The name or the ID of the SBase (according to the field
	 *         printNameIfAvailable), whose LaTeX special symbols are masked and
	 *         which is type set in typewriter font if it is an id. The mathmode
	 *         argument decides if mathtt or mathrm has to be used.
	 */
	private StringBuffer getNameOrID(SBase sbase, boolean mathMode) {
		String name = (printNameIfAvailable && sbase.isSetName()) ? sbase
				.getName() : sbase.getId();
		name = maskLaTeXspecialSymbols(name);
		if (printNameIfAvailable && sbase.isSetName())
			return new StringBuffer("\\text{" + name + "}");
		return mathtt(name);
	}

	/**
	 * This method returns the correct LaTeX expression for a function which
	 * returns the size of a compartment. This can be a volume, an area, a
	 * length or a point.
	 */
	private StringBuffer getSize(Compartment c) {
		StringBuffer value = new StringBuffer("\\mathrm{");
		switch ((int) c.getSpatialDimensions()) {
		case 3:
			value.append("vol");
			break;
		case 2:
			value.append("area");
			break;
		case 1:
			value.append("length");
			break;
		default:
			value.append("point");
			break;
		}
		value.append("}(");
		value.append(getNameOrID(c, true));
		value.append(')');
		return value;
	}

	/**
	 * This method constructs a full length SBO number from a given SBO id.
	 * Whenever a SBO number is used in the model please don't forget to add
	 * this identifier to the Set of SBO numbers (only those numbers in this set
	 * will be displayed in the glossary).
	 * 
	 * @param sbo
	 * @return
	 */
	private String getSBOnumber(int sbo) {
		String sboString = Integer.toString(sbo);
		while (sboString.length() < 7)
			sboString = '0' + sboString;
		return sboString;
	}

	/**
	 * This allows you to set the path of the logo file. It is more convenient
	 * to omit the file extension here so that LaTeX or PDFLaTeX can choose the
	 * desired file from the directory.
	 * 
	 * @param logoFilePath
	 *            Example: /home/user/logos/mylogo
	 */
	public static void setLogoFile(String logoFilePath) {
		logo = logoFilePath;
	}

	public static String getLogoFile() {
		return logo;
	}

	/**
	 * This method allows you to specify the location of the obo file containing
	 * the definitions of all SBO terms.
	 * 
	 * @param sboFilePath
	 *            Example: /home/user/controlledVocabulary/SBO.obo
	 */
	public static void setSBOFile(String sboFilePath) {
		SBOParser.setSBOOboFile(sboFilePath);
	}

	/**
	 * Returns the location of the SBO definition file.
	 * 
	 * @return
	 */
	public static String getSBOFile() {
		return SBOParser.getSBOOboFile();
	}

}
