package org.sbml.displaysbml;

import java.awt.Image;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.FilterOutputStream;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import org.jdom.JDOMException;
import org.sbml.libsbml.SBMLReader;

/**
 * Converts an SBML file into a LaTeX file
 * 
 * @since 2.0
 * @version
 * @author Andreas Dr&auml;ger (draeger) <andreas.draeger@uni-tuebingen.de>
 * @date Mar 19, 2008
 */
public class SBMLconverter {

	private boolean showGUI = false;
	private boolean showImplicitUnitDeclarations = true;
	private boolean landscape = false;
	private boolean nameIfAvailable = false;
	private boolean titlePage = false;
	private boolean typeWriter = true;
	private boolean printHelp = false;
	private boolean checkConsistency = false;
	private boolean includeMIRIAM = false;
	private short fontSize = 11;
	private File infile = null;
	private File outfile = null;
	private String paperSize = "a4";
	private String logo = "";
	private String sbo = "";
	private String miriam = "";

	/**
	 * This is not for public use.
	 * 
	 * @param args
	 */
	private SBMLconverter(String[] args) {
		analyzeArguments(args);
		if (showGUI)
			showGUI();
		if (printHelp)
			printHelp();
		try {
			performConversion(infile, outfile);
		} catch (IOException exc) {
			if (showGUI) {
				JOptionPane.showMessageDialog(null, exc.getMessage(), exc
						.getClass().getName(), JOptionPane.WARNING_MESSAGE);
			}
			exc.printStackTrace();
		} catch (JDOMException exc) {
			exc.printStackTrace();
		}
	}

	/**
	 * 
	 * @param infile
	 * @param outfile
	 * @throws IOException
	 * @throws JDOMException 
	 */
	private void performConversion(File infile, File outfile)
			throws IOException, JDOMException {
		if ((infile != null) && infile.exists() && infile.isFile()
				&& infile.canRead()) {
			long time = System.currentTimeMillis();
			System.loadLibrary("sbmlj");
			LaTeXExport export = new LaTeXExport();
			export
					.setShowImplicitUnitDeclarations(showImplicitUnitDeclarations);
			export.setFontSize(fontSize);
			export.setLandscape(landscape);
			export.setPaperSize(paperSize);
			export.setPrintNameIfAvailable(nameIfAvailable);
			export.setTitlepage(titlePage);
			export.setTypeWriter(typeWriter);
			export.setCheckConsistency(checkConsistency);
			export.setIncludeMiriam(includeMIRIAM);
			if (logo.length() > 0)
				LaTeXExport.setLogoFile(logo);
			if (sbo.length() > 0)
				LaTeXExport.setSBOFile(sbo);
			if (miriam.length() > 0)
				LaTeXExport.setMIRIAMfile(miriam);
			BufferedWriter buffer = new BufferedWriter(new FileWriter(outfile));
			export.format(
					(new SBMLReader()).readSBML(infile.getAbsolutePath()),
					buffer);
			buffer.close();
			System.out.println("Time: " + (System.currentTimeMillis() - time)
					+ " ms");
		}
	}

	/**
	 * 
	 */
	private void showGUI() {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException exc) {
			JOptionPane.showMessageDialog(null, "<html>" + exc.getMessage()
					+ "</html>", exc.getClass().getName(),
					JOptionPane.WARNING_MESSAGE);
			exc.printStackTrace();
		} catch (InstantiationException exc) {
			JOptionPane.showMessageDialog(null, "<html>" + exc.getMessage()
					+ "</html>", exc.getClass().getName(),
					JOptionPane.WARNING_MESSAGE);
			exc.printStackTrace();
		} catch (IllegalAccessException exc) {
			JOptionPane.showMessageDialog(null, "<html>" + exc.getMessage()
					+ "</html>", exc.getClass().getName(),
					JOptionPane.WARNING_MESSAGE);
			exc.printStackTrace();
		} catch (UnsupportedLookAndFeelException exc) {
			JOptionPane.showMessageDialog(null, "<html>" + exc.getMessage()
					+ "</html>", exc.getClass().getName(),
					JOptionPane.WARNING_MESSAGE);
			exc.printStackTrace();
		}

		LaTeXExportDialogPanel settingsPanel = new LaTeXExportDialogPanel();
		settingsPanel
				.setShowImplicitUnitDeclarations(showImplicitUnitDeclarations);
		settingsPanel.setFontSize(fontSize);
		settingsPanel.setLandscape(landscape);
		settingsPanel.setPaperSize(paperSize);
		settingsPanel.setPrintNameIfAvailable(nameIfAvailable);
		settingsPanel.setTitlePage(titlePage);
		settingsPanel.setTypeWriter(typeWriter);
		settingsPanel.setCheckConsistency(checkConsistency);
		settingsPanel.setIncludeMIRIAM(includeMIRIAM);
		if (infile != null)
			settingsPanel.setSBMLFile(infile);
		if (outfile != null)
			settingsPanel.setTeXFile(outfile);

		if (printHelp)
			printHelp();
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
		panel.add(settingsPanel);

		ImageIcon icon = null;
		try {
			// String fileSeparator = System.getProperty("file.separator");
			Image image = ImageIO.read(getClass().getResource(
					"SBML2LaTeX_vertical_small.png"));
			// System.getProperty("user.dir") + fileSeparator
			// + "resources" + fileSeparator
			// + "SBML2LaTeX_vertical_small.png"));
			icon = new ImageIcon(image);
			// .getScaledInstance(100, 100, Image.SCALE_SMOOTH));
			JOptionPane.getRootFrame().setIconImage(image);
		} catch (IOException exc) {
			JOptionPane.showMessageDialog(null, "<html>" + exc.getMessage()
					+ "</html>", exc.getClass().getName(),
					JOptionPane.ERROR_MESSAGE);
			exc.printStackTrace();
		}
		if (JOptionPane.OK_OPTION == JOptionPane.showConfirmDialog(null, panel,
				"LaTeX export", JOptionPane.OK_CANCEL_OPTION,
				JOptionPane.QUESTION_MESSAGE, icon)) {
			landscape = settingsPanel.isLandscape();
			typeWriter = settingsPanel.isTypeWriter();
			fontSize = settingsPanel.getFontSize();
			paperSize = settingsPanel.getPaperSize();
			showImplicitUnitDeclarations = settingsPanel
					.isShowImplicitUnitDeclarations();
			titlePage = settingsPanel.getTitlePage();
			checkConsistency = settingsPanel.isSetCheckConsistency();
			nameIfAvailable = settingsPanel.getPrintNameIfAvailable();
			includeMIRIAM = settingsPanel.isSetIncludeMIRIAM();
			if (settingsPanel.getSBMLFile().length() == 0)
				JOptionPane.showMessageDialog(null,
						"Nothing to do because no SBML file was specified.");
			else if (settingsPanel.getTeXFile().length() == 0)
				JOptionPane.showMessageDialog(null,
						"Nothing to do because no TeX file was specified");
			else {
				infile = new File(settingsPanel.getSBMLFile());
				outfile = new File(settingsPanel.getTeXFile());
			}
		}
	}

	/**
	 * 
	 */
	private void printHelp() {
		System.out.println("Usage:");
		System.out.println("SBMLconverter inFile.xml outFile.tex [options]");
		System.out.println();
		System.out.println("Possible command line options (case is ignored):");
		System.out.println("-showImplicitUnitDeclarations=<true|false>");
		System.out.println("-landscape=<true|false>");
		System.out.println("-printNameIfAvailable=<true|false>");
		System.out.println("-titlePage=<true|false>");
		System.out.println("-typeWriter=<true|false>");
		System.out.println("-fontSize=<8|9|10|11|12|14|16|17>");
		System.out.print("-paperSize=<a<0..9>|b<0..9>|c<0..9>|d<0..9>");
		System.out.println("|letter|legal|executive>");
		System.out.println("-checkConsistency=<true|false>");
		System.out.println("-includeMIRIAM=<true|false>");
		System.out.println("-logoFile=<absolute path to logo file (a graphics file)>");;
		System.out.println("-sboFile=<absolute path to SBO obo file>");
		System.out.println("-miriamFile=<absolute path to MIRIAM XML file>");
		System.out.print("--gui\t\topens a dialog window for");
		System.out.println(" convenient usage.");
		System.out.print("\t\tWith this option no in/outfile ");
		System.out.println("needs to be specified.");
		System.out.println("--help\t\tshows this overview.");
	}

	/**
	 * 
	 * @param args
	 */
	private void analyzeArguments(String[] args) {
		int i;
		for (i = 0; i < args.length; i++)
			if (args[i].toLowerCase().equals("--gui")) {
				showGUI = true;
				break;
			}
		if (((args.length < 2) || (args[0].equalsIgnoreCase("--help")))
				&& !showGUI)
			printHelp = true;
		else if (args.length > 1) {
			if (!args[0].startsWith("-"))
				infile = new File(args[0]);
			if (!args[1].startsWith("-"))
				outfile = new File(args[1]);
			for (i = 0; i < args.length; i++) {
				if (!args[i].startsWith("-"))
					continue;
				String field[] = args[i].split("=");
				if (field.length == 2) {
					if (field[0]
							.equalsIgnoreCase("-showImplicitUnitDeclarations"))
						showImplicitUnitDeclarations = Boolean
								.parseBoolean(field[1]);
					else if (field[0].equalsIgnoreCase("-landscape"))
						landscape = Boolean.parseBoolean(field[1]);
					else if (field[0].equalsIgnoreCase("-printNameIfAvailable"))
						nameIfAvailable = Boolean.parseBoolean(field[1]);
					else if (field[0].equalsIgnoreCase("-titlePage"))
						titlePage = Boolean.parseBoolean(field[1]);
					else if (field[0].equalsIgnoreCase("-typeWriter"))
						typeWriter = Boolean.parseBoolean(field[1]);
					else if (field[0].equalsIgnoreCase("-fontSize"))
						fontSize = Short.parseShort(field[1]);
					else if (field[0].equalsIgnoreCase("-paperSize"))
						paperSize = field[1];
					else if (field[0].equalsIgnoreCase("-checkConsistency"))
						checkConsistency = Boolean.parseBoolean(field[1]);
					else if (field[0].equalsIgnoreCase("-includeMIRIAM"))
						includeMIRIAM = Boolean.parseBoolean(field[1]);
					else if (field[0].equalsIgnoreCase("-logoFile"))
						logo = field[1];
					else if (field[0].equalsIgnoreCase("-sboFile"))
						sbo  = field[1];
					else if (field[0].equalsIgnoreCase("-miriamFile"))
						miriam = field[1];
					else {
						System.err.println("Illegal option/value pair:\t"
								+ field[0] + "\t" + field[1]);
						printHelp = true;
					}
				} else if (!args[i].equalsIgnoreCase("--gui"))
					printHelp = true;
			}
		}
	}

	/**
	 * Starts the SBMLconverter program
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		new SBMLconverter(args);
	}
}

/**
 * 
 * @author Andreas Dr&auml;ger <a
 *         href="mailto:andreas.draeger@uni-tuebingen.de">
 *         andreas.draeger@uni-tuebingen.de</a>
 */
class JTextAreaStream extends FilterOutputStream {
	private JTextArea area;

	public JTextAreaStream(JTextArea area) {
		super(new ByteArrayOutputStream());
		this.area = area;
	}

	@Override
	public void write(byte b[]) throws IOException {
		area.append(new String(b));
	}

	@Override
	public void write(byte b[], int off, int len) throws IOException {
		area.append(new String(b, off, len));
	}
}
