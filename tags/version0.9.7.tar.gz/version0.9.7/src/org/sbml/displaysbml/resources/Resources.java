/**
 * 
 */
package org.sbml.displaysbml.resources;

/**
 * @author Andreas Dr&auml;ger <a href="mailto:andreas.draeger@uni-tuebingen.de">andreas.draeger@uni-tuebingen.de</a>
 * @date 2009-02-16
 */
public class Resources {

}
