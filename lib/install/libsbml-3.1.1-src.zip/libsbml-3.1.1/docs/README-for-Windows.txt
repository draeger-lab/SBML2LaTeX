

               libSBML windows installation -- Documentation

                           8 September 2005

Due to the size of the documentation available for libSBML 
the SBML Team have decided not to include it within the windows 
installation programs. 

Instead the documentation is available as a separate zipped download; 
thus allowing the user to choose which documents they require and 
locate them according to preference.





