%% Description       : Script for running MATLAB tests
%% Original author(s): Michael Hucka <mhucka@caltech.edu>
%% Organization      : California Institute of Technology
%% $Id: runTests.m,v 1.1 2007/11/10 00:38:29 mhucka Exp $
%% $Source: /cvsroot/sbml/libsbml/src/bindings/matlab/test/runTests.m,v $

addpath('..')
addpath('../../..')
testBinding
exit
